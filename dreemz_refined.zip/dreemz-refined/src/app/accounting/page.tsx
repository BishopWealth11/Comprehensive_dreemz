'use client';

import React, { useState, useMemo } from 'react';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

type TransactionType = 'Revenue' | 'Expense';
type TransactionCategory =
  | 'Sales' |'Service Fee' |'Consultation' |'Rent' |'Salaries' |'Supplies' |'Utilities' |'Marketing' |'Logistics' |'Maintenance';

interface Transaction {
  id: number;
  date: string;
  description: string;
  category: TransactionCategory;
  type: TransactionType;
  amount: number;
  reference: string;
  status: 'Completed' | 'Pending' | 'Cancelled';
}

const initialTransactions: Transaction[] = [
  { id: 1, date: '2025-03-16', description: 'Showroom sale – Velvet Chesterfield Sofa', category: 'Sales', type: 'Revenue', amount: 485000, reference: 'TXN-2025-0316-001', status: 'Completed' },
  { id: 2, date: '2025-03-16', description: 'Interior design consultation – Lekki project', category: 'Consultation', type: 'Revenue', amount: 150000, reference: 'TXN-2025-0316-002', status: 'Completed' },
  { id: 3, date: '2025-03-16', description: 'Office supplies purchase', category: 'Supplies', type: 'Expense', amount: 28500, reference: 'TXN-2025-0316-003', status: 'Completed' },
  { id: 4, date: '2025-03-15', description: 'Showroom sale – Marble Coffee Table', category: 'Sales', type: 'Revenue', amount: 215000, reference: 'TXN-2025-0315-001', status: 'Completed' },
  { id: 5, date: '2025-03-15', description: 'Monthly electricity bill', category: 'Utilities', type: 'Expense', amount: 45000, reference: 'TXN-2025-0315-002', status: 'Completed' },
  { id: 6, date: '2025-03-15', description: 'Instagram ad campaign – March', category: 'Marketing', type: 'Expense', amount: 80000, reference: 'TXN-2025-0315-003', status: 'Completed' },
  { id: 7, date: '2025-03-14', description: 'Service fee – Exterior design Abuja', category: 'Service Fee', type: 'Revenue', amount: 320000, reference: 'TXN-2025-0314-001', status: 'Completed' },
  { id: 8, date: '2025-03-14', description: 'Delivery logistics – client orders', category: 'Logistics', type: 'Expense', amount: 35000, reference: 'TXN-2025-0314-002', status: 'Completed' },
  { id: 9, date: '2025-03-13', description: 'Showroom sale – Brass Pendant Light Cluster', category: 'Sales', type: 'Revenue', amount: 128000, reference: 'TXN-2025-0313-001', status: 'Completed' },
  { id: 10, date: '2025-03-13', description: 'Staff salaries – March first half', category: 'Salaries', type: 'Expense', amount: 750000, reference: 'TXN-2025-0313-002', status: 'Completed' },
  { id: 11, date: '2025-03-12', description: 'Consultation fee – VI penthouse project', category: 'Consultation', type: 'Revenue', amount: 200000, reference: 'TXN-2025-0312-001', status: 'Completed' },
  { id: 12, date: '2025-03-12', description: 'Showroom maintenance & cleaning', category: 'Maintenance', type: 'Expense', amount: 22000, reference: 'TXN-2025-0312-002', status: 'Completed' },
  { id: 13, date: '2025-03-11', description: 'Showroom sale – Handwoven Moroccan Rug', category: 'Sales', type: 'Revenue', amount: 95000, reference: 'TXN-2025-0311-001', status: 'Completed' },
  { id: 14, date: '2025-03-11', description: 'Monthly showroom rent', category: 'Rent', type: 'Expense', amount: 350000, reference: 'TXN-2025-0311-002', status: 'Completed' },
  { id: 15, date: '2025-03-10', description: 'Service fee – Hotel lobby redesign', category: 'Service Fee', type: 'Revenue', amount: 580000, reference: 'TXN-2025-0310-001', status: 'Completed' },
  { id: 16, date: '2025-03-10', description: 'Supplier payment – Stone & Form Nigeria', category: 'Supplies', type: 'Expense', amount: 120000, reference: 'TXN-2025-0310-002', status: 'Completed' },
  { id: 17, date: '2025-03-09', description: 'Showroom sale – Rattan Dining Set', category: 'Sales', type: 'Revenue', amount: 310000, reference: 'TXN-2025-0309-001', status: 'Completed' },
  { id: 18, date: '2025-03-09', description: 'Internet & phone bills', category: 'Utilities', type: 'Expense', amount: 18500, reference: 'TXN-2025-0309-002', status: 'Completed' },
  { id: 19, date: '2025-03-08', description: 'Consultation fee – Ikoyi residence', category: 'Consultation', type: 'Revenue', amount: 175000, reference: 'TXN-2025-0308-001', status: 'Pending' },
  { id: 20, date: '2025-03-08', description: 'Logistics – bulk delivery Abuja', category: 'Logistics', type: 'Expense', amount: 55000, reference: 'TXN-2025-0308-002', status: 'Completed' },
];

const formatNGN = (amount: number) =>
  new Intl.NumberFormat('en-NG', { style: 'currency', currency: 'NGN', minimumFractionDigits: 0 }).format(amount);

const CATEGORIES: TransactionCategory[] = ['Sales', 'Service Fee', 'Consultation', 'Rent', 'Salaries', 'Supplies', 'Utilities', 'Marketing', 'Logistics', 'Maintenance'];

type ActiveTab = 'transactions' | 'balance' | 'reports';

export default function AccountingPage() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('transactions');
  const [transactions, setTransactions] = useState<Transaction[]>(initialTransactions);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'All' | TransactionType>('All');
  const [filterCategory, setFilterCategory] = useState<'All' | TransactionCategory>('All');
  const [filterStatus, setFilterStatus] = useState<'All' | 'Completed' | 'Pending' | 'Cancelled'>('All');
  const [showAddModal, setShowAddModal] = useState(false);
  const [reportPeriod, setReportPeriod] = useState<'week' | 'month' | 'quarter'>('month');

  const [newTx, setNewTx] = useState<Omit<Transaction, 'id' | 'reference'>>({
    date: new Date().toISOString().split('T')[0],
    description: '',
    category: 'Sales',
    type: 'Revenue',
    amount: 0,
    status: 'Completed',
  });

  // Filtered transactions
  const filtered = useMemo(() => {
    return transactions.filter((tx) => {
      const matchSearch =
        tx.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tx.reference.toLowerCase().includes(searchQuery.toLowerCase());
      const matchType = filterType === 'All' || tx.type === filterType;
      const matchCat = filterCategory === 'All' || tx.category === filterCategory;
      const matchStatus = filterStatus === 'All' || tx.status === filterStatus;
      return matchSearch && matchType && matchCat && matchStatus;
    });
  }, [transactions, searchQuery, filterType, filterCategory, filterStatus]);

  // Summary stats
  const totalRevenue = useMemo(() => transactions.filter((t) => t.type === 'Revenue' && t.status !== 'Cancelled').reduce((s, t) => s + t.amount, 0), [transactions]);
  const totalExpenses = useMemo(() => transactions.filter((t) => t.type === 'Expense' && t.status !== 'Cancelled').reduce((s, t) => s + t.amount, 0), [transactions]);
  const netProfit = totalRevenue - totalExpenses;
  const profitMargin = totalRevenue > 0 ? ((netProfit / totalRevenue) * 100).toFixed(1) : '0.0';

  // Daily balance sheet data
  const dailyBalances = useMemo(() => {
    const grouped: Record<string, { revenue: number; expenses: number; date: string }> = {};
    transactions.filter((t) => t.status !== 'Cancelled').forEach((tx) => {
      if (!grouped[tx.date]) grouped[tx.date] = { revenue: 0, expenses: 0, date: tx.date };
      if (tx.type === 'Revenue') grouped[tx.date].revenue += tx.amount;
      else grouped[tx.date].expenses += tx.amount;
    });
    return Object.values(grouped).sort((a, b) => b.date.localeCompare(a.date));
  }, [transactions]);

  // Category breakdown for reports
  const revenueByCategory = useMemo(() => {
    const map: Record<string, number> = {};
    transactions.filter((t) => t.type === 'Revenue' && t.status !== 'Cancelled').forEach((t) => {
      map[t.category] = (map[t.category] || 0) + t.amount;
    });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [transactions]);

  const expenseByCategory = useMemo(() => {
    const map: Record<string, number> = {};
    transactions.filter((t) => t.type === 'Expense' && t.status !== 'Cancelled').forEach((t) => {
      map[t.category] = (map[t.category] || 0) + t.amount;
    });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [transactions]);

  const handleAddTransaction = () => {
    if (!newTx.description || newTx.amount <= 0) return;
    const id = transactions.length + 1;
    const ref = `TXN-${newTx.date.replace(/-/g, '')}-${String(id).padStart(3, '0')}`;
    setTransactions([{ ...newTx, id, reference: ref }, ...transactions]);
    setShowAddModal(false);
    setNewTx({ date: new Date().toISOString().split('T')[0], description: '', category: 'Sales', type: 'Revenue', amount: 0, status: 'Completed' });
  };

  const tabs: { key: ActiveTab; label: string }[] = [
    { key: 'transactions', label: 'Transaction Log' },
    { key: 'balance', label: 'Daily Balance Sheets' },
    { key: 'reports', label: 'Financial Reports' },
  ];

  return (
    <div className="min-h-screen" style={{ background: 'var(--color-background)' }}>
      <Header />

      <main className="pt-28 pb-20 px-6 md:px-10 max-w-7xl mx-auto">
        {/* Page Header */}
        <div className="mb-10">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-muted mb-3">
            <Link href="/homepage" className="hover:text-foreground transition-colors">Home</Link>
            <span>/</span>
            <span style={{ color: 'var(--color-gold)' }}>Accounting</span>
          </div>
          <h1 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-2">Accounting</h1>
          <p className="text-muted text-sm">Financial overview, transaction records, and reports — all in Nigerian Naira (₦)</p>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          {[
            { label: 'Total Revenue', value: formatNGN(totalRevenue), color: '#22c55e', icon: '↑' },
            { label: 'Total Expenses', value: formatNGN(totalExpenses), color: '#ef4444', icon: '↓' },
            { label: 'Net Profit', value: formatNGN(netProfit), color: netProfit >= 0 ? '#C9A84C' : '#ef4444', icon: '₦' },
            { label: 'Profit Margin', value: `${profitMargin}%`, color: '#C9A84C', icon: '%' },
          ].map((kpi) => (
            <div
              key={kpi.label}
              className="rounded-2xl p-5 border"
              style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold uppercase tracking-[0.14em] text-muted">{kpi.label}</span>
                <span className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold" style={{ background: `${kpi.color}20`, color: kpi.color }}>{kpi.icon}</span>
              </div>
              <p className="font-display text-xl md:text-2xl font-bold" style={{ color: kpi.color }}>{kpi.value}</p>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-8 p-1 rounded-xl w-fit" style={{ background: 'var(--color-surface)', border: '1px solid var(--color-border)' }}>
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`px-5 py-2.5 rounded-lg text-xs font-semibold uppercase tracking-[0.14em] transition-all duration-200 ${
                activeTab === tab.key ? 'text-background' : 'text-muted hover:text-foreground'
              }`}
              style={activeTab === tab.key ? { background: 'var(--color-gold)' } : {}}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* ─── TRANSACTION LOG TAB ─── */}
        {activeTab === 'transactions' && (
          <div>
            {/* Filters */}
            <div className="flex flex-wrap gap-3 mb-6 items-center justify-between">
              <div className="flex flex-wrap gap-3">
                <input
                  type="text"
                  placeholder="Search transactions..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="px-4 py-2.5 rounded-xl text-sm border outline-none focus:ring-2 w-56"
                  style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)', color: 'var(--color-foreground)', focusRingColor: 'var(--color-gold)' }}
                />
                <select
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value as 'All' | TransactionType)}
                  className="px-4 py-2.5 rounded-xl text-sm border outline-none cursor-pointer"
                  style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)', color: 'var(--color-foreground)' }}
                >
                  <option value="All">All Types</option>
                  <option value="Revenue">Revenue</option>
                  <option value="Expense">Expense</option>
                </select>
                <select
                  value={filterCategory}
                  onChange={(e) => setFilterCategory(e.target.value as 'All' | TransactionCategory)}
                  className="px-4 py-2.5 rounded-xl text-sm border outline-none cursor-pointer"
                  style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)', color: 'var(--color-foreground)' }}
                >
                  <option value="All">All Categories</option>
                  {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value as 'All' | 'Completed' | 'Pending' | 'Cancelled')}
                  className="px-4 py-2.5 rounded-xl text-sm border outline-none cursor-pointer"
                  style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)', color: 'var(--color-foreground)' }}
                >
                  <option value="All">All Status</option>
                  <option value="Completed">Completed</option>
                  <option value="Pending">Pending</option>
                  <option value="Cancelled">Cancelled</option>
                </select>
              </div>
              <button
                onClick={() => setShowAddModal(true)}
                className="btn-gold px-5 py-2.5 rounded-xl text-xs font-bold uppercase tracking-[0.12em] flex items-center gap-2"
              >
                <span>+</span> Add Transaction
              </button>
            </div>

            {/* Transaction Table */}
            <div className="rounded-2xl overflow-hidden border" style={{ borderColor: 'var(--color-border)' }}>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr style={{ background: 'var(--color-surface)', borderBottom: '1px solid var(--color-border)' }}>
                      {['Date', 'Reference', 'Description', 'Category', 'Type', 'Amount', 'Status'].map((h) => (
                        <th key={h} className="px-4 py-3.5 text-left text-xs font-semibold uppercase tracking-[0.14em] text-muted whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="px-4 py-12 text-center text-muted text-sm">No transactions found</td>
                      </tr>
                    ) : (
                      filtered.map((tx, i) => (
                        <tr
                          key={tx.id}
                          className="transition-colors hover:bg-opacity-50"
                          style={{
                            background: i % 2 === 0 ? 'var(--color-background)' : 'var(--color-surface)',
                            borderBottom: '1px solid var(--color-border)',
                          }}
                        >
                          <td className="px-4 py-3.5 text-muted whitespace-nowrap">{tx.date}</td>
                          <td className="px-4 py-3.5 font-mono text-xs text-muted whitespace-nowrap">{tx.reference}</td>
                          <td className="px-4 py-3.5 text-foreground max-w-xs">{tx.description}</td>
                          <td className="px-4 py-3.5 whitespace-nowrap">
                            <span className="px-2.5 py-1 rounded-full text-xs font-semibold" style={{ background: 'var(--color-gold-light, rgba(201,168,76,0.12))', color: 'var(--color-gold)' }}>
                              {tx.category}
                            </span>
                          </td>
                          <td className="px-4 py-3.5 whitespace-nowrap">
                            <span
                              className="px-2.5 py-1 rounded-full text-xs font-bold"
                              style={{
                                background: tx.type === 'Revenue' ? 'rgba(34,197,94,0.12)' : 'rgba(239,68,68,0.12)',
                                color: tx.type === 'Revenue' ? '#22c55e' : '#ef4444',
                              }}
                            >
                              {tx.type}
                            </span>
                          </td>
                          <td className="px-4 py-3.5 font-semibold whitespace-nowrap" style={{ color: tx.type === 'Revenue' ? '#22c55e' : '#ef4444' }}>
                            {tx.type === 'Revenue' ? '+' : '-'}{formatNGN(tx.amount)}
                          </td>
                          <td className="px-4 py-3.5 whitespace-nowrap">
                            <span
                              className="px-2.5 py-1 rounded-full text-xs font-semibold"
                              style={{
                                background: tx.status === 'Completed' ? 'rgba(34,197,94,0.12)' : tx.status === 'Pending' ? 'rgba(234,179,8,0.12)' : 'rgba(239,68,68,0.12)',
                                color: tx.status === 'Completed' ? '#22c55e' : tx.status === 'Pending' ? '#eab308' : '#ef4444',
                              }}
                            >
                              {tx.status}
                            </span>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
              <div className="px-4 py-3 border-t flex items-center justify-between" style={{ borderColor: 'var(--color-border)', background: 'var(--color-surface)' }}>
                <span className="text-xs text-muted">{filtered.length} transaction{filtered.length !== 1 ? 's' : ''} shown</span>
                <span className="text-xs text-muted">Showing all records</span>
              </div>
            </div>
          </div>
        )}

        {/* ─── DAILY BALANCE SHEETS TAB ─── */}
        {activeTab === 'balance' && (
          <div>
            <p className="text-sm text-muted mb-6">Daily summary of revenue, expenses, and net balance for each business day.</p>
            <div className="space-y-4">
              {dailyBalances.map((day) => {
                const net = day.revenue - day.expenses;
                const revenueWidth = day.revenue + day.expenses > 0 ? (day.revenue / (day.revenue + day.expenses)) * 100 : 50;
                return (
                  <div
                    key={day.date}
                    className="rounded-2xl p-5 border"
                    style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}
                  >
                    <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
                      <div>
                        <p className="font-display font-semibold text-foreground text-lg">{new Date(day.date + 'T00:00:00').toLocaleDateString('en-NG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                        <p className="text-xs text-muted mt-0.5">{transactions.filter((t) => t.date === day.date).length} transactions</p>
                      </div>
                      <div className="flex gap-6 text-right">
                        <div>
                          <p className="text-xs text-muted uppercase tracking-[0.12em] mb-1">Revenue</p>
                          <p className="font-semibold text-green-500">{formatNGN(day.revenue)}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted uppercase tracking-[0.12em] mb-1">Expenses</p>
                          <p className="font-semibold text-red-400">{formatNGN(day.expenses)}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted uppercase tracking-[0.12em] mb-1">Net</p>
                          <p className="font-bold text-lg" style={{ color: net >= 0 ? 'var(--color-gold)' : '#ef4444' }}>{net >= 0 ? '+' : ''}{formatNGN(net)}</p>
                        </div>
                      </div>
                    </div>
                    {/* Revenue vs Expense bar */}
                    <div className="h-2 rounded-full overflow-hidden" style={{ background: 'rgba(239,68,68,0.2)' }}>
                      <div className="h-full rounded-full transition-all duration-500" style={{ width: `${revenueWidth}%`, background: 'linear-gradient(90deg, #22c55e, #C9A84C)' }} />
                    </div>
                    <div className="flex justify-between mt-1.5">
                      <span className="text-xs text-green-500 font-medium">Revenue {revenueWidth.toFixed(0)}%</span>
                      <span className="text-xs text-red-400 font-medium">Expenses {(100 - revenueWidth).toFixed(0)}%</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ─── FINANCIAL REPORTS TAB ─── */}
        {activeTab === 'reports' && (
          <div>
            {/* Period selector */}
            <div className="flex gap-2 mb-8">
              {(['week', 'month', 'quarter'] as const).map((p) => (
                <button
                  key={p}
                  onClick={() => setReportPeriod(p)}
                  className="px-4 py-2 rounded-lg text-xs font-semibold uppercase tracking-[0.12em] transition-all duration-200 border"
                  style={{
                    background: reportPeriod === p ? 'var(--color-gold)' : 'var(--color-surface)',
                    color: reportPeriod === p ? 'var(--color-background)' : 'var(--color-muted)',
                    borderColor: reportPeriod === p ? 'var(--color-gold)' : 'var(--color-border)',
                  }}
                >
                  {p === 'week' ? 'This Week' : p === 'month' ? 'This Month' : 'This Quarter'}
                </button>
              ))}
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              {/* Revenue Breakdown */}
              <div className="rounded-2xl p-6 border" style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
                <h3 className="font-display font-semibold text-foreground text-lg mb-1">Revenue Breakdown</h3>
                <p className="text-xs text-muted mb-5">By category — {formatNGN(totalRevenue)} total</p>
                <div className="space-y-4">
                  {revenueByCategory.map(([cat, amount]) => {
                    const pct = totalRevenue > 0 ? (amount / totalRevenue) * 100 : 0;
                    return (
                      <div key={cat}>
                        <div className="flex justify-between items-center mb-1.5">
                          <span className="text-sm text-foreground font-medium">{cat}</span>
                          <div className="text-right">
                            <span className="text-sm font-semibold text-green-500">{formatNGN(amount)}</span>
                            <span className="text-xs text-muted ml-2">{pct.toFixed(1)}%</span>
                          </div>
                        </div>
                        <div className="h-2 rounded-full overflow-hidden" style={{ background: 'rgba(34,197,94,0.1)' }}>
                          <div className="h-full rounded-full" style={{ width: `${pct}%`, background: 'linear-gradient(90deg, #22c55e, #C9A84C)' }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Expense Breakdown */}
              <div className="rounded-2xl p-6 border" style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
                <h3 className="font-display font-semibold text-foreground text-lg mb-1">Expense Breakdown</h3>
                <p className="text-xs text-muted mb-5">By category — {formatNGN(totalExpenses)} total</p>
                <div className="space-y-4">
                  {expenseByCategory.map(([cat, amount]) => {
                    const pct = totalExpenses > 0 ? (amount / totalExpenses) * 100 : 0;
                    return (
                      <div key={cat}>
                        <div className="flex justify-between items-center mb-1.5">
                          <span className="text-sm text-foreground font-medium">{cat}</span>
                          <div className="text-right">
                            <span className="text-sm font-semibold text-red-400">{formatNGN(amount)}</span>
                            <span className="text-xs text-muted ml-2">{pct.toFixed(1)}%</span>
                          </div>
                        </div>
                        <div className="h-2 rounded-full overflow-hidden" style={{ background: 'rgba(239,68,68,0.1)' }}>
                          <div className="h-full rounded-full" style={{ width: `${pct}%`, background: 'linear-gradient(90deg, #ef4444, #C9A84C)' }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* P&L Summary */}
              <div className="rounded-2xl p-6 border md:col-span-2" style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
                <h3 className="font-display font-semibold text-foreground text-lg mb-1">Profit & Loss Summary</h3>
                <p className="text-xs text-muted mb-6">Consolidated financial performance overview</p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { label: 'Gross Revenue', value: formatNGN(totalRevenue), color: '#22c55e' },
                    { label: 'Total Expenses', value: formatNGN(totalExpenses), color: '#ef4444' },
                    { label: 'Net Profit / Loss', value: formatNGN(netProfit), color: netProfit >= 0 ? '#C9A84C' : '#ef4444' },
                    { label: 'Profit Margin', value: `${profitMargin}%`, color: '#C9A84C' },
                  ].map((item) => (
                    <div key={item.label} className="text-center p-4 rounded-xl" style={{ background: 'var(--color-background)' }}>
                      <p className="text-xs text-muted uppercase tracking-[0.12em] mb-2">{item.label}</p>
                      <p className="font-display text-xl font-bold" style={{ color: item.color }}>{item.value}</p>
                    </div>
                  ))}
                </div>

                {/* Visual P&L bar */}
                <div className="mt-6">
                  <div className="flex justify-between text-xs text-muted mb-2">
                    <span>Revenue vs Expenses</span>
                    <span>{totalRevenue > 0 ? ((totalExpenses / totalRevenue) * 100).toFixed(1) : 0}% expense ratio</span>
                  </div>
                  <div className="h-4 rounded-full overflow-hidden flex" style={{ background: 'var(--color-background)' }}>
                    <div
                      className="h-full transition-all duration-700"
                      style={{
                        width: totalRevenue > 0 ? `${Math.min((totalExpenses / totalRevenue) * 100, 100)}%` : '0%',
                        background: 'linear-gradient(90deg, #ef4444, #C9A84C)',
                      }}
                    />
                    <div
                      className="h-full transition-all duration-700"
                      style={{
                        flex: 1,
                        background: 'linear-gradient(90deg, #C9A84C, #22c55e)',
                      }}
                    />
                  </div>
                  <div className="flex justify-between mt-1.5">
                    <span className="text-xs text-red-400">Expenses: {formatNGN(totalExpenses)}</span>
                    <span className="text-xs text-green-500">Net Profit: {formatNGN(netProfit)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Add Transaction Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(8px)' }}>
          <div className="w-full max-w-lg rounded-3xl p-8 border" style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-display text-2xl font-bold text-foreground">Add Transaction</h2>
              <button onClick={() => setShowAddModal(false)} className="w-9 h-9 rounded-full flex items-center justify-center text-muted hover:text-foreground transition-colors" style={{ background: 'var(--color-background)' }}>✕</button>
            </div>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-[0.12em] text-muted mb-2">Date</label>
                  <input type="date" value={newTx.date} onChange={(e) => setNewTx({ ...newTx, date: e.target.value })} className="w-full px-4 py-3 rounded-xl border text-sm outline-none" style={{ background: 'var(--color-background)', borderColor: 'var(--color-border)', color: 'var(--color-foreground)' }} />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-[0.12em] text-muted mb-2">Type</label>
                  <select value={newTx.type} onChange={(e) => setNewTx({ ...newTx, type: e.target.value as TransactionType })} className="w-full px-4 py-3 rounded-xl border text-sm outline-none cursor-pointer" style={{ background: 'var(--color-background)', borderColor: 'var(--color-border)', color: 'var(--color-foreground)' }}>
                    <option value="Revenue">Revenue</option>
                    <option value="Expense">Expense</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold uppercase tracking-[0.12em] text-muted mb-2">Description</label>
                <input type="text" placeholder="Transaction description..." value={newTx.description} onChange={(e) => setNewTx({ ...newTx, description: e.target.value })} className="w-full px-4 py-3 rounded-xl border text-sm outline-none" style={{ background: 'var(--color-background)', borderColor: 'var(--color-border)', color: 'var(--color-foreground)' }} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-[0.12em] text-muted mb-2">Category</label>
                  <select value={newTx.category} onChange={(e) => setNewTx({ ...newTx, category: e.target.value as TransactionCategory })} className="w-full px-4 py-3 rounded-xl border text-sm outline-none cursor-pointer" style={{ background: 'var(--color-background)', borderColor: 'var(--color-border)', color: 'var(--color-foreground)' }}>
                    {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-[0.12em] text-muted mb-2">Amount (₦)</label>
                  <input type="number" placeholder="0" min={0} value={newTx.amount || ''} onChange={(e) => setNewTx({ ...newTx, amount: parseFloat(e.target.value) || 0 })} className="w-full px-4 py-3 rounded-xl border text-sm outline-none" style={{ background: 'var(--color-background)', borderColor: 'var(--color-border)', color: 'var(--color-foreground)' }} />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold uppercase tracking-[0.12em] text-muted mb-2">Status</label>
                <select value={newTx.status} onChange={(e) => setNewTx({ ...newTx, status: e.target.value as 'Completed' | 'Pending' | 'Cancelled' })} className="w-full px-4 py-3 rounded-xl border text-sm outline-none cursor-pointer" style={{ background: 'var(--color-background)', borderColor: 'var(--color-border)', color: 'var(--color-foreground)' }}>
                  <option value="Completed">Completed</option>
                  <option value="Pending">Pending</option>
                  <option value="Cancelled">Cancelled</option>
                </select>
              </div>
            </div>
            <div className="flex gap-3 mt-7">
              <button onClick={() => setShowAddModal(false)} className="flex-1 px-5 py-3 rounded-xl text-sm font-semibold border transition-colors" style={{ borderColor: 'var(--color-border)', color: 'var(--color-muted)' }}>Cancel</button>
              <button onClick={handleAddTransaction} className="flex-1 btn-gold px-5 py-3 rounded-xl text-sm font-bold">Add Transaction</button>
            </div>
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
}

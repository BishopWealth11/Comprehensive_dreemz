'use client';

import React, { useRef } from 'react';
import Link from 'next/link';
import AppImage from '@/components/ui/AppImage';
import { useScrollReveal } from '@/hooks/useScrollReveal';

export default function CTASection() {
  const sectionRef = useRef<HTMLElement>(null);
  useScrollReveal(sectionRef, 0.2);

  return (
    <section
      ref={sectionRef}
      id="contact"
      className="py-28 md:py-36 px-6 md:px-10 bg-dark relative overflow-hidden grain-overlay"
    >
      {/* Background image */}
      <div className="absolute inset-0 z-0">
        <AppImage
          src="https://img.rocket.new/generatedImages/rocket_gen_img_1561a8b67-1773666240146.png"
          alt="Elegant interior space background for Dreemz consultation CTA"
          fill
          className="object-cover object-center opacity-20"
          sizes="100vw"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-dark via-dark/95 to-dark/80" />
      </div>

      {/* Decorative circles */}
      <div className="absolute top-1/2 right-20 -translate-y-1/2 w-80 h-80 rounded-full border border-primary/10 animate-slow-spin hidden lg:block z-10" />
      <div
        className="absolute top-1/2 right-20 -translate-y-1/2 w-48 h-48 rounded-full border border-primary/15 animate-slow-spin hidden lg:block z-10"
        style={{ animationDirection: 'reverse', animationDuration: '12s' }}
      />

      <div className="max-w-7xl mx-auto relative z-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left */}
          <div className="scroll-reveal">
            <span className="section-tag mb-6 text-primary">Start Your Project</span>
            <h2 className="font-display text-[clamp(2.6rem,5vw,5rem)] font-light leading-[1.05] tracking-tightest text-white mb-8">
              Ready to transform{' '}
              <span className="italic text-primary">your space?</span>
            </h2>
            <p className="text-lg text-white/60 leading-relaxed mb-10 max-w-lg">
              Book a free consultation with our design team. We&apos;ll visit your space, understand
              your vision, and present a tailored concept within 5 working days.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href="tel:+2348000000000"
                className="btn-gold inline-flex items-center justify-center gap-3 px-8 py-4 rounded-full font-semibold text-[14px] uppercase tracking-[0.12em]"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                  />
                </svg>
                Call Us Now
              </a>
              <Link
                href="/showroom-items"
                className="inline-flex items-center justify-center gap-3 px-8 py-4 rounded-full font-semibold text-[14px] uppercase tracking-[0.12em] border border-white/25 text-white hover:bg-white/10 transition-all duration-300"
              >
                Browse Showroom
              </Link>
            </div>
          </div>

          {/* Right: Contact form */}
          <div className="scroll-reveal">
            <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-3xl p-8 md:p-10">
              <h3 className="font-display text-2xl font-medium text-white mb-8">
                Send us a message
              </h3>
              {/* Note: replace with a server action or API route for production */}
              <div className="space-y-7">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-7">
                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-[0.18em] text-white/40 mb-2">
                      Full Name
                    </label>
                    <input
                      type="text"
                      placeholder="Chidi Okeke"
                      className="w-full bg-transparent border-b border-white/20 py-3 text-white placeholder:text-white/20 focus:outline-none focus:border-primary transition-colors text-base"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-[0.18em] text-white/40 mb-2">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      placeholder="+234 800 000 0000"
                      className="w-full bg-transparent border-b border-white/20 py-3 text-white placeholder:text-white/20 focus:outline-none focus:border-primary transition-colors text-base"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-[0.18em] text-white/40 mb-2">
                    Email Address
                  </label>
                  <input
                    type="email"
                    placeholder="chidi@example.com"
                    className="w-full bg-transparent border-b border-white/20 py-3 text-white placeholder:text-white/20 focus:outline-none focus:border-primary transition-colors text-base"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-[0.18em] text-white/40 mb-2">
                    Project Type
                  </label>
                  <select className="w-full bg-transparent border-b border-white/20 py-3 text-white/60 focus:outline-none focus:border-primary transition-colors text-base appearance-none cursor-pointer">
                    <option value="" className="bg-dark">Select project type</option>
                    <option value="residential" className="bg-dark">Residential Interior</option>
                    <option value="commercial" className="bg-dark">Commercial Interior</option>
                    <option value="exterior" className="bg-dark">Exterior &amp; Landscape</option>
                    <option value="renovation" className="bg-dark">Renovation &amp; Fit-Out</option>
                    <option value="showroom" className="bg-dark">Showroom Purchase</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-[0.18em] text-white/40 mb-2">
                    Message
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Tell us about your space and vision..."
                    className="w-full bg-transparent border-b border-white/20 py-3 text-white placeholder:text-white/20 focus:outline-none focus:border-primary transition-colors text-base resize-none"
                  />
                </div>
                <button
                  type="button"
                  className="btn-gold w-full py-4 rounded-full font-bold text-[14px] uppercase tracking-[0.15em]"
                >
                  Send Message
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

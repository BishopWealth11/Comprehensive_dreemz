'use client';

import React, { useEffect, useRef, useCallback } from 'react';
import Link from 'next/link';
import AppImage from '@/components/ui/AppImage';

const stats = [
  { value: '12+', label: 'Years of Excellence' },
  { value: '340+', label: 'Projects Completed' },
  { value: '200+', label: 'Showroom Items' },
  { value: '98%', label: 'Client Satisfaction' },
];

export default function HeroSection() {
  const heroRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);

  const handleScroll = useCallback(() => {
    const bg = heroRef.current?.querySelector<HTMLElement>('.parallax-bg');
    if (bg) bg.style.transform = `translateY(${window.scrollY * 0.35}px)`;
  }, []);

  useEffect(() => {
    // Line reveal
    headlineRef.current?.querySelectorAll<HTMLElement>('.line-reveal').forEach((line, i) => {
      setTimeout(() => line.classList.add('revealed'), 600 + i * 180);
    });

    // Stats reveal
    setTimeout(() => statsRef.current?.classList.add('revealed'), 1400);

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [handleScroll]);

  return (
    <section
      ref={heroRef}
      className="relative min-h-screen flex flex-col overflow-hidden grain-overlay"
      id="hero"
    >
      {/* Background with parallax */}
      <div className="parallax-bg absolute inset-0 -top-20 -bottom-20 z-0">
        <AppImage
          src="https://img.rocket.new/generatedImages/rocket_gen_img_1cf2f8c75-1773137719905.png"
          alt="Elegant living room with premium furniture and warm lighting by Dreemz Interiors"
          fill
          priority
          className="object-cover object-center"
          sizes="100vw"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0F0D08]/50 via-[#0F0D08]/20 to-[#0F0D08]/80" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0F0D08]/60 via-transparent to-transparent" />
      </div>

      {/* Decorative rings */}
      <div className="absolute top-1/3 right-16 w-64 h-64 rounded-full border border-primary/20 animate-slow-spin hidden lg:block z-10" />
      <div
        className="absolute top-1/3 right-16 w-40 h-40 rounded-full border border-primary/10 animate-slow-spin hidden lg:block z-10"
        style={{ animationDirection: 'reverse', animationDuration: '15s' }}
      />

      {/* Content */}
      <div className="relative z-20 flex-1 flex flex-col justify-between max-w-7xl mx-auto w-full px-6 md:px-10 pt-40 pb-16">
        {/* Badge */}
        <div className="mb-8">
          <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-[11px] font-bold uppercase tracking-[0.2em] text-primary-light border border-primary/30 bg-white/5 backdrop-blur-sm">
            <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse-glow" />
            Lagos &amp; Abuja, Nigeria
          </span>
        </div>

        {/* Headline */}
        <div ref={headlineRef} className="mb-12">
          <h1
            className="font-display text-[clamp(3.2rem,8vw,8rem)] font-light leading-[1.05] tracking-tightest text-white"
            aria-label="Transform Every Space Into Art"
          >
            <span className="line-reveal"><span>Transform Every</span></span>
            <span className="line-reveal mt-1"><span>Space Into</span></span>
            <span className="line-reveal mt-1">
              <span className="italic text-gold-gradient">Art.</span>
            </span>
          </h1>
        </div>

        {/* Subheadline + CTAs */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-end border-t border-white/15 pt-10">
          <div className="md:col-span-6">
            <p className="text-lg md:text-xl text-white/75 leading-relaxed max-w-lg font-light">
              Dreemz Interior and Exterior Concepts designs, furnishes, and transforms residential
              and commercial spaces across Nigeria — from concept to completion.
            </p>
          </div>
          <div className="md:col-span-6 flex flex-col sm:flex-row gap-4 md:justify-end">
            <Link
              href="/showroom-items"
              className="btn-gold inline-flex items-center justify-center gap-3 px-8 py-4 rounded-full font-semibold text-[14px] uppercase tracking-[0.12em]"
            >
              Browse Showroom
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
              </svg>
            </Link>
            <a
              href="#portfolio"
              className="inline-flex items-center justify-center gap-3 px-8 py-4 rounded-full font-semibold text-[14px] uppercase tracking-[0.12em] border border-white/30 text-white hover:bg-white/10 transition-all duration-300"
            >
              View Portfolio
            </a>
          </div>
        </div>

        {/* Stats bar */}
        <div
          ref={statsRef}
          className="stagger-children mt-14 grid grid-cols-2 md:grid-cols-4 gap-px bg-white/10 rounded-2xl overflow-hidden backdrop-blur-sm"
        >
          {stats.map((stat) => (
            <div key={stat.label} className="bg-white/5 px-6 py-5 flex flex-col gap-1">
              <div className="font-display text-3xl md:text-4xl font-medium text-primary-light leading-none">
                {stat.value}
              </div>
              <div className="text-[11px] font-semibold uppercase tracking-[0.15em] text-white/50">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-2 opacity-50">
        <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-white">Scroll</span>
        <div className="w-px h-12 bg-gradient-to-b from-white/60 to-transparent" />
      </div>
    </section>
  );
}

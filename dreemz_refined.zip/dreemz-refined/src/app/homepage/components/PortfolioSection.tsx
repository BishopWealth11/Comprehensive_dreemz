'use client';

import React, { useRef } from 'react';
import Link from 'next/link';
import AppImage from '@/components/ui/AppImage';
import { useScrollReveal } from '@/hooks/useScrollReveal';

const portfolioItems = [
  {
    id: 1,
    title: 'Lekki Phase 1 Penthouse',
    category: 'Residential',
    location: 'Lagos',
    year: '2025',
    image: 'https://img.rocket.new/generatedImages/rocket_gen_img_15fed27fb-1772893766018.png',
    alt: 'Modern penthouse living room with floor-to-ceiling windows and luxury furniture in Lagos',
    height: 'h-[480px] md:h-full',
  },
  {
    id: 2,
    title: 'Victoria Island Office Suite',
    category: 'Commercial',
    location: 'Lagos',
    year: '2025',
    image: 'https://images.unsplash.com/photo-1655745653127-4d6837baf958',
    alt: 'Contemporary office interior with warm wood tones and modern workstations',
    height: 'h-56',
  },
  {
    id: 3,
    title: 'Maitama Villa Bedroom',
    category: 'Residential',
    location: 'Abuja',
    year: '2024',
    image: 'https://img.rocket.new/generatedImages/rocket_gen_img_1cbe95b3f-1772893765660.png',
    alt: 'Luxury master bedroom with upholstered headboard and ambient lighting in Abuja villa',
    height: 'h-56',
  },
  {
    id: 4,
    title: 'Ikoyi Dining Experience',
    category: 'Residential',
    location: 'Lagos',
    year: '2024',
    image: 'https://images.unsplash.com/photo-1672630488350-f7990421e358',
    alt: 'Elegant dining room with custom table and statement chandelier in Ikoyi home',
    height: 'h-56',
  },
  {
    id: 5,
    title: 'Asokoro Exterior Landscape',
    category: 'Exterior',
    location: 'Abuja',
    year: '2025',
    image: 'https://img.rocket.new/generatedImages/rocket_gen_img_13dc422ac-1772210226514.png',
    alt: 'Beautiful exterior landscaping and facade design of luxury home in Abuja',
    height: 'h-56',
  },
];

const [featured, ...rest] = portfolioItems;

export default function PortfolioSection() {
  const sectionRef = useRef<HTMLElement>(null);
  useScrollReveal(sectionRef, 0.15);

  return (
    <section ref={sectionRef} id="portfolio" className="py-28 md:py-36 px-6 md:px-10 bg-background">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-16 scroll-reveal">
          <div>
            <span className="section-tag mb-4">Our Portfolio</span>
            <h2 className="font-display text-[clamp(2.4rem,5vw,5rem)] font-light leading-[1.1] tracking-display text-foreground max-w-xl">
              Spaces that tell{' '}
              <span className="italic text-primary">your story</span>
            </h2>
          </div>
          <p className="max-w-sm text-base text-muted leading-relaxed">
            From intimate residential interiors to grand commercial spaces — every project is a
            masterpiece of craft and intention.
          </p>
        </div>

        {/* Bento Portfolio Grid */}
        <div className="stagger-children grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-5">
          {/* Featured item */}
          <div
            className="md:col-span-2 md:row-span-2 img-zoom rounded-3xl overflow-hidden relative group cursor-pointer"
            style={{ minHeight: '480px' }}
          >
            <AppImage
              src={featured.image}
              alt={featured.alt}
              fill
              className="object-cover"
              sizes="(max-width: 768px) 100vw, 66vw"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-dark/80 via-dark/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            <div className="absolute bottom-0 left-0 right-0 p-8 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
              <span className="badge-gold mb-3 inline-block">{featured.category}</span>
              <h3 className="font-display text-2xl font-medium text-white mb-1">{featured.title}</h3>
              <p className="text-white/60 text-sm">
                {featured.location} · {featured.year}
              </p>
            </div>
          </div>

          {/* Smaller items */}
          {rest.map((item) => (
            <div
              key={item.id}
              className={`img-zoom rounded-3xl overflow-hidden relative group cursor-pointer ${item.height}`}
              style={{ minHeight: '220px' }}
            >
              <AppImage
                src={item.image}
                alt={item.alt}
                fill
                className="object-cover"
                sizes="(max-width: 768px) 100vw, 33vw"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-dark/80 via-dark/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="absolute bottom-0 left-0 right-0 p-6 translate-y-3 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-[400ms]">
                <span className="badge-gold mb-2 inline-block">{item.category}</span>
                <h3 className="font-display text-lg font-medium text-white">{item.title}</h3>
                <p className="text-white/60 text-xs mt-0.5">
                  {item.location} · {item.year}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-12 flex justify-center scroll-reveal">
          <Link
            href="/portfolio"
            className="inline-flex items-center gap-3 text-[13px] font-bold uppercase tracking-[0.18em] text-foreground border-b-2 border-primary pb-1 hover:border-foreground transition-all duration-300"
          >
            View Full Portfolio
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </Link>
        </div>
      </div>
    </section>
  );
}

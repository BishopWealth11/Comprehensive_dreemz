'use client';

import React, { useRef } from 'react';
import { useScrollReveal } from '@/hooks/useScrollReveal';

const services = [
  {
    id: 1,
    number: '01',
    title: 'Interior Design & Consultation',
    description:
      'Full-service interior design from concept boards to final installation. We handle space planning, colour palettes, material selection, and project management.',
    tags: ['Residential', 'Commercial', 'Hospitality'],
  },
  {
    id: 2,
    number: '02',
    title: 'Furniture Supply & Installation',
    description:
      'Premium furniture sourced from our curated showroom or custom-ordered to your specifications — delivered and installed with precision.',
    tags: ['Custom Orders', 'Import Logistics', 'White Glove Install'],
  },
  {
    id: 3,
    number: '03',
    title: 'Exterior & Landscape Design',
    description:
      'Transforming outdoor spaces with thoughtful landscaping, facade treatments, and exterior lighting that complements your interior vision.',
    tags: ['Landscaping', 'Facade Work', 'Lighting'],
  },
  {
    id: 4,
    number: '04',
    title: 'Renovation & Fit-Out',
    description:
      'End-to-end renovation services including flooring, ceilings, partitioning, and complete fit-out for residential and commercial properties.',
    tags: ['Flooring', 'False Ceilings', 'Full Fit-Out'],
  },
];

export default function ServicesSection() {
  const sectionRef = useRef<HTMLElement>(null);
  useScrollReveal(sectionRef, 0.1);

  return (
    <section ref={sectionRef} id="services" className="py-28 md:py-36 bg-dark overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-20 scroll-reveal">
          <div className="lg:col-span-7">
            <span className="section-tag mb-5 text-primary">What We Do</span>
            <h2 className="font-display text-[clamp(2.4rem,5vw,5.5rem)] font-light leading-[1.05] tracking-tightest text-white">
              Full-spectrum design,{' '}
              <span className="italic text-primary">delivered.</span>
            </h2>
          </div>
          <div className="lg:col-span-5">
            <p className="text-lg text-white/60 leading-relaxed">
              From the first sketch to the final finishing touch — Dreemz handles every detail so
              you can simply enjoy the result.
            </p>
          </div>
        </div>

        <div className="space-y-0 stagger-children">
          {services.map((service) => (
            <div
              key={service.id}
              className="grid grid-cols-1 md:grid-cols-12 gap-6 md:gap-10 items-start py-10 border-t border-white/[0.08] group cursor-default"
            >
              <div className="md:col-span-1">
                <span className="font-display text-5xl font-light text-white/15 group-hover:text-primary/40 transition-colors duration-500">
                  {service.number}
                </span>
              </div>
              <div className="md:col-span-5">
                <h3 className="font-display text-2xl md:text-3xl font-medium text-white group-hover:text-primary-light transition-colors duration-300 mb-4 leading-tight">
                  {service.title}
                </h3>
                <p className="text-white/55 leading-relaxed text-base">{service.description}</p>
              </div>
              <div className="md:col-span-4 flex flex-wrap gap-2 md:pt-2">
                {service.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-3 py-1.5 text-[11px] font-bold uppercase tracking-[0.12em] rounded-full border border-white/10 text-white/40 group-hover:border-primary/30 group-hover:text-primary/60 transition-all duration-300"
                  >
                    {tag}
                  </span>
                ))}
              </div>
              <div className="md:col-span-2 flex justify-end items-start">
                <div className="w-10 h-10 rounded-full border border-white/15 flex items-center justify-center text-white/30 group-hover:bg-primary group-hover:border-primary group-hover:text-dark transition-all duration-300">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                  </svg>
                </div>
              </div>
            </div>
          ))}
          <div className="border-t border-white/[0.08]" />
        </div>
      </div>
    </section>
  );
}

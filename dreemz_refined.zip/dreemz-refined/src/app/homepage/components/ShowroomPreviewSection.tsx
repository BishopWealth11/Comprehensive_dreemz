'use client';

import React, { useRef } from 'react';
import Link from 'next/link';
import AppImage from '@/components/ui/AppImage';
import { useScrollReveal } from '@/hooks/useScrollReveal';

const featuredItems = [
  {
    id: 1,
    name: 'Castello Sectional Sofa',
    category: 'Living Room',
    price: 2_850_000,
    originalPrice: 3_200_000,
    image: 'https://images.unsplash.com/photo-1651764126724-5af9b63ec825',
    alt: 'Modern grey sectional sofa with deep cushions and clean lines',
    badge: 'Bestseller',
  },
  {
    id: 2,
    name: 'Meridian King Bed Frame',
    category: 'Bedroom',
    price: 1_950_000,
    originalPrice: null,
    image: 'https://img.rocket.new/generatedImages/rocket_gen_img_1b7259e54-1773090346501.png',
    alt: 'Upholstered king size bed frame with tufted headboard in cream fabric',
    badge: 'New Arrival',
  },
  {
    id: 3,
    name: 'Artisan Dining Table',
    category: 'Dining',
    price: 1_680_000,
    originalPrice: 1_900_000,
    image: 'https://img.rocket.new/generatedImages/rocket_gen_img_17e95032f-1772864330048.png',
    alt: 'Solid wood dining table with metal base for six to eight persons',
    badge: null,
  },
  {
    id: 4,
    name: 'Luxe Executive Chair',
    category: 'Office',
    price: 420_000,
    originalPrice: null,
    image: 'https://img.rocket.new/generatedImages/rocket_gen_img_1562f2b95-1772115480185.png',
    alt: 'Premium leather executive office chair with lumbar support',
    badge: 'Limited Stock',
  },
];

const formatNGN = (amount: number) => `₦${amount.toLocaleString('en-NG')}`;

export default function ShowroomPreviewSection() {
  const sectionRef = useRef<HTMLElement>(null);
  useScrollReveal(sectionRef, 0.1);

  return (
    <section ref={sectionRef} id="showroom" className="py-28 md:py-36 px-6 md:px-10 bg-cream-dark">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-16 scroll-reveal">
          <div>
            <span className="section-tag mb-4">Showroom</span>
            <h2 className="font-display text-[clamp(2.4rem,5vw,5rem)] font-light leading-[1.1] tracking-display text-foreground">
              Curated pieces,{' '}
              <br className="hidden md:block" />
              <span className="italic text-primary">exceptional quality</span>
            </h2>
          </div>
          <div className="flex flex-col gap-4 items-start md:items-end">
            <p className="max-w-sm text-base text-muted leading-relaxed md:text-right">
              Browse our handpicked collection of premium furniture and décor — all priced in Naira,
              no hidden charges.
            </p>
            <Link
              href="/showroom-items"
              className="btn-gold inline-flex items-center gap-2 px-6 py-3 rounded-full text-[13px] font-bold uppercase tracking-[0.12em]"
            >
              View All Items
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
              </svg>
            </Link>
          </div>
        </div>

        {/* Product grid */}
        <div className="stagger-children grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {featuredItems.map((item) => (
            <div key={item.id} className="product-card group">
              {/* Image */}
              <div className="relative overflow-hidden" style={{ height: '260px' }}>
                <AppImage
                  src={item.image}
                  alt={item.alt}
                  fill
                  className="object-cover transition-transform duration-700 group-hover:scale-105"
                  sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
                />
                {item.badge && (
                  <div className="absolute top-4 left-4">
                    <span className="badge-gold">{item.badge}</span>
                  </div>
                )}
                <div className="absolute inset-0 bg-dark/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <Link
                    href="/showroom-items"
                    className="bg-white text-foreground px-6 py-2.5 rounded-full text-[12px] font-bold uppercase tracking-[0.12em] hover:bg-primary transition-colors duration-200"
                  >
                    View Details
                  </Link>
                </div>
              </div>

              {/* Info */}
              <div className="p-5">
                <span className="text-[11px] font-bold uppercase tracking-[0.15em] text-primary mb-1 block">
                  {item.category}
                </span>
                <h3 className="font-display text-lg font-medium text-foreground mb-3 leading-tight">
                  {item.name}
                </h3>
                <div className="flex items-center justify-between">
                  <div className="flex flex-col">
                    <span className="text-xl font-bold text-foreground">{formatNGN(item.price)}</span>
                    {item.originalPrice && (
                      <span className="text-sm text-muted line-through">
                        {formatNGN(item.originalPrice)}
                      </span>
                    )}
                  </div>
                  <button
                    aria-label={`Save ${item.name}`}
                    className="w-10 h-10 rounded-full border border-[var(--color-border)] flex items-center justify-center text-muted hover:bg-primary hover:border-primary hover:text-dark transition-all duration-200"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
                      />
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

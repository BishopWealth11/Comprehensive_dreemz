'use client';

import React, { useRef } from 'react';
import AppImage from '@/components/ui/AppImage';
import { useScrollReveal } from '@/hooks/useScrollReveal';

const testimonials = [
  {
    id: 1,
    quote:
      'Dreemz turned our Lekki apartment into a magazine spread. The attention to detail was extraordinary — they understood our lifestyle before we even articulated it.',
    author: 'Adaeze Okonkwo',
    role: 'Homeowner, Lekki Phase 1',
    image: 'https://img.rocket.new/generatedImages/rocket_gen_img_15fcfcc61-1772182273229.png',
    alt: 'Adaeze Okonkwo, satisfied Dreemz client from Lagos',
    rating: 5,
  },
  {
    id: 2,
    quote:
      "Our Victoria Island office now reflects the premium brand we've built. Clients comment on the space every single time. Worth every naira.",
    author: 'Emeka Nwosu',
    role: 'CEO, Nwosu & Partners',
    image: 'https://img.rocket.new/generatedImages/rocket_gen_img_14d8bee40-1773666246452.png',
    alt: 'Emeka Nwosu, business owner who used Dreemz for office design',
    rating: 5,
  },
  {
    id: 3,
    quote:
      'From the showroom furniture to the final installation — the quality is unmatched. My Maitama villa feels like a five-star hotel every morning.',
    author: 'Halima Bello',
    role: 'Homeowner, Maitama Abuja',
    image: 'https://img.rocket.new/generatedImages/rocket_gen_img_1f9a987e7-1763298449686.png',
    alt: 'Halima Bello, Dreemz client from Abuja',
    rating: 5,
  },
];

export default function TestimonialsSection() {
  const sectionRef = useRef<HTMLElement>(null);
  useScrollReveal(sectionRef, 0.1);

  return (
    <section
      ref={sectionRef}
      className="py-28 md:py-36 px-6 md:px-10 bg-cream-darker relative overflow-hidden"
    >
      <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-primary/5 blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-64 h-64 rounded-full bg-primary/[0.08] blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center mb-16 scroll-reveal">
          <span className="section-tag justify-center mb-5">Client Stories</span>
          <h2 className="font-display text-[clamp(2.2rem,4.5vw,4.5rem)] font-light leading-[1.1] tracking-display text-foreground">
            What our clients <span className="italic text-primary">say</span>
          </h2>
        </div>

        <div className="stagger-children grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((t) => (
            <div
              key={t.id}
              className="bg-white rounded-3xl p-8 border border-[var(--color-border)] hover-lift flex flex-col gap-6"
            >
              <div className="flex gap-1" aria-label={`${t.rating} out of 5 stars`}>
                {Array.from({ length: t.rating }).map((_, i) => (
                  <svg key={i} className="w-4 h-4 text-primary" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                  </svg>
                ))}
              </div>

              <blockquote className="font-display text-xl font-light leading-relaxed text-foreground italic flex-1">
                &ldquo;{t.quote}&rdquo;
              </blockquote>

              <div className="flex items-center gap-4 pt-4 border-t border-[var(--color-border)]">
                <div className="w-12 h-12 rounded-full overflow-hidden flex-shrink-0">
                  <AppImage
                    src={t.image}
                    alt={t.alt}
                    width={48}
                    height={48}
                    className="object-cover w-full h-full"
                  />
                </div>
                <div>
                  <div className="font-semibold text-foreground text-sm">{t.author}</div>
                  <div className="text-muted text-xs">{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

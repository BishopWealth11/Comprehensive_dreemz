'use client';

import React, { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import AppImage from '@/components/ui/AppImage';

type Category = 'Furniture' | 'Lighting' | 'Textiles' | 'Decor' | 'Flooring' | 'Outdoor';
type Status = 'In Stock' | 'Low Stock' | 'Out of Stock';

interface InventoryItem {
  id: number;
  name: string;
  sku: string;
  category: Category;
  quantity: number;
  minStock: number;
  price: number;
  supplier: string;
  status: Status;
  image: string;
  alt: string;
  lastUpdated: string;
}

const initialInventory: InventoryItem[] = [
{
  id: 1,
  name: 'Velvet Chesterfield Sofa',
  sku: 'DRZ-FRN-001',
  category: 'Furniture',
  quantity: 8,
  minStock: 3,
  price: 485000,
  supplier: 'Lagos Luxury Furnishings',
  status: 'In Stock',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1c9755a36-1772199201732.png",
  alt: 'Elegant velvet chesterfield sofa in deep teal color',
  lastUpdated: '2025-03-10'
},
{
  id: 2,
  name: 'Brass Pendant Light Cluster',
  sku: 'DRZ-LGT-002',
  category: 'Lighting',
  quantity: 2,
  minStock: 4,
  price: 128000,
  supplier: 'Abuja Lighting Co.',
  status: 'Low Stock',
  image: "https://images.unsplash.com/photo-1602598166020-100f3f9d4294",
  alt: 'Cluster of brass pendant lights hanging from ceiling',
  lastUpdated: '2025-03-12'
},
{
  id: 3,
  name: 'Hand-woven Moroccan Rug',
  sku: 'DRZ-TXT-003',
  category: 'Textiles',
  quantity: 0,
  minStock: 2,
  price: 95000,
  supplier: 'Artisan Imports Ltd.',
  status: 'Out of Stock',
  image: "https://images.unsplash.com/photo-1726208206176-5df7681c3a13",
  alt: 'Colorful hand-woven Moroccan rug with geometric patterns',
  lastUpdated: '2025-03-08'
},
{
  id: 4,
  name: 'Marble Coffee Table',
  sku: 'DRZ-FRN-004',
  category: 'Furniture',
  quantity: 5,
  minStock: 2,
  price: 215000,
  supplier: 'Stone & Form Nigeria',
  status: 'In Stock',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1abfdcbcd-1772441227795.png",
  alt: 'Elegant white marble coffee table with gold metal legs',
  lastUpdated: '2025-03-14'
},
{
  id: 5,
  name: 'Linen Curtain Panels (Pair)',
  sku: 'DRZ-TXT-005',
  category: 'Textiles',
  quantity: 14,
  minStock: 6,
  price: 42000,
  supplier: 'Fabric House Lagos',
  status: 'In Stock',
  image: "https://images.unsplash.com/photo-1593909840438-48825492a8b7",
  alt: 'Flowing natural linen curtain panels in cream color',
  lastUpdated: '2025-03-11'
},
{
  id: 6,
  name: 'Ceramic Vase Set',
  sku: 'DRZ-DCR-006',
  category: 'Decor',
  quantity: 3,
  minStock: 5,
  price: 28500,
  supplier: 'Craft & Clay Abuja',
  status: 'Low Stock',
  image: "https://images.unsplash.com/photo-1734107640189-4974176150f9",
  alt: 'Set of three artisan ceramic vases in earth tones',
  lastUpdated: '2025-03-09'
},
{
  id: 7,
  name: 'Herringbone Oak Flooring (per m²)',
  sku: 'DRZ-FLR-007',
  category: 'Flooring',
  quantity: 120,
  minStock: 50,
  price: 18500,
  supplier: 'Premium Floors NG',
  status: 'In Stock',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1de5376b1-1768522404327.png",
  alt: 'Elegant herringbone pattern oak hardwood flooring',
  lastUpdated: '2025-03-13'
},
{
  id: 8,
  name: 'Rattan Outdoor Lounge Set',
  sku: 'DRZ-OUT-008',
  category: 'Outdoor',
  quantity: 4,
  minStock: 2,
  price: 320000,
  supplier: 'Outdoor Living Lagos',
  status: 'In Stock',
  image: "https://images.unsplash.com/photo-1609347744425-175ecbd3cc0e",
  alt: 'Modern rattan outdoor lounge set with cream cushions',
  lastUpdated: '2025-03-15'
}];


const categories: Category[] = ['Furniture', 'Lighting', 'Textiles', 'Decor', 'Flooring', 'Outdoor'];
const statuses: Status[] = ['In Stock', 'Low Stock', 'Out of Stock'];

const statusColors: Record<Status, string> = {
  'In Stock': 'text-green-700 bg-green-50 border-green-200',
  'Low Stock': 'text-amber-700 bg-amber-50 border-amber-200',
  'Out of Stock': 'text-red-700 bg-red-50 border-red-200'
};

const categoryColors: Record<Category, string> = {
  Furniture: 'text-blue-700 bg-blue-50',
  Lighting: 'text-yellow-700 bg-yellow-50',
  Textiles: 'text-purple-700 bg-purple-50',
  Decor: 'text-pink-700 bg-pink-50',
  Flooring: 'text-orange-700 bg-orange-50',
  Outdoor: 'text-green-700 bg-green-50'
};

function formatNGN(amount: number) {
  return new Intl.NumberFormat('en-NG', { style: 'currency', currency: 'NGN', maximumFractionDigits: 0 }).format(amount);
}

interface ModalProps {
  item?: InventoryItem | null;
  onClose: () => void;
  onSave: (item: Omit<InventoryItem, 'id' | 'lastUpdated'> & {id?: number;}) => void;
}

function ItemModal({ item, onClose, onSave }: ModalProps) {
  const [form, setForm] = useState({
    name: item?.name ?? '',
    sku: item?.sku ?? '',
    category: (item?.category ?? 'Furniture') as Category,
    quantity: item?.quantity ?? 0,
    minStock: item?.minStock ?? 2,
    price: item?.price ?? 0,
    supplier: item?.supplier ?? '',
    image: item?.image ?? '',
    alt: item?.alt ?? ''
  });

  const deriveStatus = (qty: number, min: number): Status => {
    if (qty === 0) return 'Out of Stock';
    if (qty <= min) return 'Low Stock';
    return 'In Stock';
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...form,
      id: item?.id,
      status: deriveStatus(form.quantity, form.minStock)
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-dark/60 backdrop-blur-sm" />
      <div
        className="relative bg-background rounded-3xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}>
        
        <div className="p-8">
          <div className="flex items-center justify-between mb-8">
            <h2 className="font-display text-2xl font-medium text-foreground">
              {item ? 'Edit Item' : 'Add New Item'}
            </h2>
            <button onClick={onClose} className="w-9 h-9 rounded-full bg-cream-dark flex items-center justify-center hover:bg-cream-darker transition-colors">
              <svg className="w-5 h-5 text-muted" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <label className="block text-[11px] font-bold uppercase tracking-[0.18em] text-muted mb-2">Item Name</label>
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  required
                  placeholder="e.g. Velvet Chesterfield Sofa"
                  className="input-dreemz" />
                
              </div>
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-[0.18em] text-muted mb-2">SKU</label>
                <input
                  type="text"
                  value={form.sku}
                  onChange={(e) => setForm({ ...form, sku: e.target.value })}
                  required
                  placeholder="DRZ-CAT-000"
                  className="input-dreemz" />
                
              </div>
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-[0.18em] text-muted mb-2">Category</label>
                <select
                  value={form.category}
                  onChange={(e) => setForm({ ...form, category: e.target.value as Category })}
                  className="input-dreemz appearance-none cursor-pointer">
                  
                  {categories.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-[0.18em] text-muted mb-2">Quantity</label>
                <input
                  type="number"
                  min={0}
                  value={form.quantity}
                  onChange={(e) => setForm({ ...form, quantity: parseInt(e.target.value) || 0 })}
                  required
                  className="input-dreemz" />
                
              </div>
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-[0.18em] text-muted mb-2">Min. Stock Level</label>
                <input
                  type="number"
                  min={0}
                  value={form.minStock}
                  onChange={(e) => setForm({ ...form, minStock: parseInt(e.target.value) || 0 })}
                  required
                  className="input-dreemz" />
                
              </div>
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-[0.18em] text-muted mb-2">Price (₦)</label>
                <input
                  type="number"
                  min={0}
                  value={form.price}
                  onChange={(e) => setForm({ ...form, price: parseInt(e.target.value) || 0 })}
                  required
                  className="input-dreemz" />
                
              </div>
              <div className="col-span-2">
                <label className="block text-[11px] font-bold uppercase tracking-[0.18em] text-muted mb-2">Supplier</label>
                <input
                  type="text"
                  value={form.supplier}
                  onChange={(e) => setForm({ ...form, supplier: e.target.value })}
                  placeholder="Supplier name"
                  className="input-dreemz" />
                
              </div>
              <div className="col-span-2">
                <label className="block text-[11px] font-bold uppercase tracking-[0.18em] text-muted mb-2">Image URL</label>
                <input
                  type="url"
                  value={form.image}
                  onChange={(e) => setForm({ ...form, image: e.target.value })}
                  placeholder="https://..."
                  className="input-dreemz" />
                
              </div>
              <div className="col-span-2">
                <label className="block text-[11px] font-bold uppercase tracking-[0.18em] text-muted mb-2">Image Alt Text</label>
                <input
                  type="text"
                  value={form.alt}
                  onChange={(e) => setForm({ ...form, alt: e.target.value })}
                  placeholder="Describe the image"
                  className="input-dreemz" />
                
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <button type="button" onClick={onClose} className="flex-1 py-3 rounded-full border border-[var(--color-border)] text-[13px] font-bold uppercase tracking-[0.12em] text-muted hover:text-foreground transition-colors">
                Cancel
              </button>
              <button type="submit" className="flex-1 btn-gold py-3 rounded-full text-[13px] font-bold uppercase tracking-[0.12em]">
                {item ? 'Save Changes' : 'Add Item'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>);

}

export default function InventoryPage() {
  const [inventory, setInventory] = useState<InventoryItem[]>(initialInventory);
  const [search, setSearch] = useState('');
  const [filterCategory, setFilterCategory] = useState<Category | 'All'>('All');
  const [filterStatus, setFilterStatus] = useState<Status | 'All'>('All');
  const [modalOpen, setModalOpen] = useState(false);
  const [editItem, setEditItem] = useState<InventoryItem | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);
  const [viewMode, setViewMode] = useState<'table' | 'grid'>('table');
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) entry.target.classList.add('revealed');
        });
      },
      { threshold: 0.1 }
    );
    const els = sectionRef.current?.querySelectorAll('.scroll-reveal');
    els?.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const filtered = inventory.filter((item) => {
    const matchSearch =
    item.name.toLowerCase().includes(search.toLowerCase()) ||
    item.sku.toLowerCase().includes(search.toLowerCase()) ||
    item.supplier.toLowerCase().includes(search.toLowerCase());
    const matchCategory = filterCategory === 'All' || item.category === filterCategory;
    const matchStatus = filterStatus === 'All' || item.status === filterStatus;
    return matchSearch && matchCategory && matchStatus;
  });

  const stats = {
    total: inventory.length,
    inStock: inventory.filter((i) => i.status === 'In Stock').length,
    lowStock: inventory.filter((i) => i.status === 'Low Stock').length,
    outOfStock: inventory.filter((i) => i.status === 'Out of Stock').length,
    totalValue: inventory.reduce((sum, i) => sum + i.price * i.quantity, 0)
  };

  const handleSave = (data: Omit<InventoryItem, 'id' | 'lastUpdated'> & {id?: number;}) => {
    const today = new Date().toISOString().split('T')[0];
    if (data.id) {
      setInventory((prev) =>
      prev.map((item) =>
      item.id === data.id ? { ...item, ...data, id: data.id!, lastUpdated: today } : item
      )
      );
    } else {
      const newItem: InventoryItem = {
        ...data,
        id: Math.max(...inventory.map((i) => i.id)) + 1,
        lastUpdated: today
      };
      setInventory((prev) => [newItem, ...prev]);
    }
    setModalOpen(false);
    setEditItem(null);
  };

  const handleDelete = (id: number) => {
    setInventory((prev) => prev.filter((item) => item.id !== id));
    setDeleteConfirm(null);
  };

  return (
    <>
      <Header />
      <main className="min-h-screen bg-background pt-24 pb-20">
        <div ref={sectionRef} className="max-w-7xl mx-auto px-6 md:px-10">

          {/* Page Header */}
          <div className="scroll-reveal mb-10">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
              <div>
                <div className="flex items-center gap-3 mb-3">
                  <Link href="/homepage" className="text-muted text-sm hover:text-foreground transition-colors">Home</Link>
                  <span className="text-muted/40">›</span>
                  <span className="text-sm text-foreground font-medium">Inventory</span>
                </div>
                <span className="section-tag mb-3">Staff Portal</span>
                <h1 className="font-display text-[clamp(2rem,4vw,3.5rem)] font-light leading-[1.1] tracking-display text-foreground">
                  Inventory{' '}
                  <span className="italic text-primary">Management</span>
                </h1>
                <p className="text-muted mt-3 max-w-md">Track, manage and update all showroom inventory items in real time.</p>
              </div>
              <button
                onClick={() => {setEditItem(null);setModalOpen(true);}}
                className="btn-gold inline-flex items-center gap-2 px-6 py-3 rounded-full text-[13px] font-bold uppercase tracking-[0.12em] self-start md:self-auto">
                
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
                Add Item
              </button>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="scroll-reveal grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
            {[
            { label: 'Total Items', value: stats.total, icon: '📦', color: 'text-foreground' },
            { label: 'In Stock', value: stats.inStock, icon: '✅', color: 'text-green-700' },
            { label: 'Low Stock', value: stats.lowStock, icon: '⚠️', color: 'text-amber-700' },
            { label: 'Out of Stock', value: stats.outOfStock, icon: '❌', color: 'text-red-700' }].
            map((stat) =>
            <div key={stat.label} className="bg-white rounded-2xl border border-[var(--color-border)] p-5">
                <div className="text-2xl mb-2">{stat.icon}</div>
                <div className={`font-display text-3xl font-medium ${stat.color}`}>{stat.value}</div>
                <div className="text-xs text-muted font-semibold uppercase tracking-[0.12em] mt-1">{stat.label}</div>
              </div>
            )}
          </div>

          {/* Total Value Banner */}
          <div className="scroll-reveal mb-8 bg-foreground rounded-2xl p-5 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold uppercase tracking-[0.18em] text-white/50 mb-1">Total Inventory Value</div>
              <div className="font-display text-2xl md:text-3xl font-medium text-primary">{formatNGN(stats.totalValue)}</div>
            </div>
            <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
              <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
          </div>

          {/* Filters & Search */}
          <div className="scroll-reveal flex flex-col md:flex-row gap-4 mb-8">
            {/* Search */}
            <div className="relative flex-1">
              <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <input
                type="text"
                placeholder="Search by name, SKU or supplier..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-11 pr-4 py-3 bg-white border border-[var(--color-border)] rounded-full text-sm text-foreground placeholder:text-muted focus:outline-none focus:border-primary transition-colors" />
              
            </div>

            {/* Category filter */}
            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value as Category | 'All')}
              className="px-4 py-3 bg-white border border-[var(--color-border)] rounded-full text-sm text-foreground focus:outline-none focus:border-primary appearance-none cursor-pointer min-w-[160px]">
              
              <option value="All">All Categories</option>
              {categories.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>

            {/* Status filter */}
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as Status | 'All')}
              className="px-4 py-3 bg-white border border-[var(--color-border)] rounded-full text-sm text-foreground focus:outline-none focus:border-primary appearance-none cursor-pointer min-w-[160px]">
              
              <option value="All">All Statuses</option>
              {statuses.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>

            {/* View toggle */}
            <div className="flex bg-cream-dark rounded-full p-1 gap-1">
              <button
                onClick={() => setViewMode('table')}
                className={`px-4 py-2 rounded-full text-xs font-bold uppercase tracking-[0.12em] transition-all ${viewMode === 'table' ? 'bg-foreground text-white' : 'text-muted hover:text-foreground'}`}>
                
                Table
              </button>
              <button
                onClick={() => setViewMode('grid')}
                className={`px-4 py-2 rounded-full text-xs font-bold uppercase tracking-[0.12em] transition-all ${viewMode === 'grid' ? 'bg-foreground text-white' : 'text-muted hover:text-foreground'}`}>
                
                Grid
              </button>
            </div>
          </div>

          {/* Results count */}
          <div className="text-sm text-muted mb-4">
            Showing <span className="font-semibold text-foreground">{filtered.length}</span> of {inventory.length} items
          </div>

          {/* Table View */}
          {viewMode === 'table' &&
          <div className="scroll-reveal bg-white rounded-3xl border border-[var(--color-border)] overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-[var(--color-border)] bg-cream-dark">
                      <th className="text-left px-6 py-4 text-[11px] font-bold uppercase tracking-[0.18em] text-muted">Item</th>
                      <th className="text-left px-4 py-4 text-[11px] font-bold uppercase tracking-[0.18em] text-muted">SKU</th>
                      <th className="text-left px-4 py-4 text-[11px] font-bold uppercase tracking-[0.18em] text-muted">Category</th>
                      <th className="text-left px-4 py-4 text-[11px] font-bold uppercase tracking-[0.18em] text-muted">Qty</th>
                      <th className="text-left px-4 py-4 text-[11px] font-bold uppercase tracking-[0.18em] text-muted">Price</th>
                      <th className="text-left px-4 py-4 text-[11px] font-bold uppercase tracking-[0.18em] text-muted">Status</th>
                      <th className="text-left px-4 py-4 text-[11px] font-bold uppercase tracking-[0.18em] text-muted">Supplier</th>
                      <th className="text-right px-6 py-4 text-[11px] font-bold uppercase tracking-[0.18em] text-muted">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.length === 0 ?
                  <tr>
                        <td colSpan={8} className="text-center py-16 text-muted">
                          <div className="text-4xl mb-3">📭</div>
                          <div className="font-medium">No items found</div>
                          <div className="text-sm mt-1">Try adjusting your search or filters</div>
                        </td>
                      </tr> :

                  filtered.map((item) =>
                  <tr key={item.id} className="border-b border-[var(--color-border)] last:border-0 hover:bg-cream-dark/50 transition-colors">
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-3">
                              <div className="w-12 h-12 rounded-xl overflow-hidden flex-shrink-0 relative">
                                <AppImage src={item.image} alt={item.alt} fill className="object-cover" sizes="48px" />
                              </div>
                              <div>
                                <div className="font-semibold text-foreground text-sm">{item.name}</div>
                                <div className="text-xs text-muted mt-0.5">Updated {item.lastUpdated}</div>
                              </div>
                            </div>
                          </td>
                          <td className="px-4 py-4">
                            <span className="font-mono text-xs text-muted bg-cream-dark px-2 py-1 rounded-lg">{item.sku}</span>
                          </td>
                          <td className="px-4 py-4">
                            <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${categoryColors[item.category]}`}>
                              {item.category}
                            </span>
                          </td>
                          <td className="px-4 py-4">
                            <span className={`font-bold text-sm ${item.quantity === 0 ? 'text-red-600' : item.quantity <= item.minStock ? 'text-amber-600' : 'text-foreground'}`}>
                              {item.quantity}
                            </span>
                            <span className="text-xs text-muted ml-1">/ min {item.minStock}</span>
                          </td>
                          <td className="px-4 py-4 font-semibold text-sm text-foreground">{formatNGN(item.price)}</td>
                          <td className="px-4 py-4">
                            <span className={`text-xs font-semibold px-2.5 py-1 rounded-full border ${statusColors[item.status]}`}>
                              {item.status}
                            </span>
                          </td>
                          <td className="px-4 py-4 text-sm text-muted">{item.supplier}</td>
                          <td className="px-6 py-4">
                            <div className="flex items-center justify-end gap-2">
                              <button
                          onClick={() => {setEditItem(item);setModalOpen(true);}}
                          className="w-8 h-8 rounded-full bg-cream-dark hover:bg-primary/10 flex items-center justify-center transition-colors group"
                          aria-label="Edit item">
                          
                                <svg className="w-4 h-4 text-muted group-hover:text-primary transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                </svg>
                              </button>
                              <button
                          onClick={() => setDeleteConfirm(item.id)}
                          className="w-8 h-8 rounded-full bg-cream-dark hover:bg-red-50 flex items-center justify-center transition-colors group"
                          aria-label="Delete item">
                          
                                <svg className="w-4 h-4 text-muted group-hover:text-red-600 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                </svg>
                              </button>
                            </div>
                          </td>
                        </tr>
                  )
                  }
                  </tbody>
                </table>
              </div>
            </div>
          }

          {/* Grid View */}
          {viewMode === 'grid' &&
          <div className="scroll-reveal grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {filtered.length === 0 ?
            <div className="col-span-full text-center py-16 text-muted">
                  <div className="text-4xl mb-3">📭</div>
                  <div className="font-medium">No items found</div>
                </div> :

            filtered.map((item) =>
            <div key={item.id} className="bg-white rounded-2xl border border-[var(--color-border)] overflow-hidden hover-lift group">
                    <div className="relative h-48 overflow-hidden">
                      <AppImage src={item.image} alt={item.alt} fill className="object-cover transition-transform duration-500 group-hover:scale-105" sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw" />
                      <div className="absolute top-3 left-3">
                        <span className={`text-xs font-semibold px-2.5 py-1 rounded-full border ${statusColors[item.status]}`}>
                          {item.status}
                        </span>
                      </div>
                    </div>
                    <div className="p-4">
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <h3 className="font-semibold text-foreground text-sm leading-snug">{item.name}</h3>
                        <span className={`text-xs font-semibold px-2 py-0.5 rounded-full flex-shrink-0 ${categoryColors[item.category]}`}>
                          {item.category}
                        </span>
                      </div>
                      <div className="font-mono text-xs text-muted mb-3">{item.sku}</div>
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <div className="text-xs text-muted">Quantity</div>
                          <div className={`font-bold text-sm ${item.quantity === 0 ? 'text-red-600' : item.quantity <= item.minStock ? 'text-amber-600' : 'text-foreground'}`}>
                            {item.quantity} units
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-xs text-muted">Price</div>
                          <div className="font-bold text-sm text-foreground">{formatNGN(item.price)}</div>
                        </div>
                      </div>
                      <div className="text-xs text-muted mb-4 truncate">{item.supplier}</div>
                      <div className="flex gap-2">
                        <button
                    onClick={() => {setEditItem(item);setModalOpen(true);}}
                    className="flex-1 py-2 rounded-full bg-cream-dark hover:bg-primary/10 text-xs font-bold uppercase tracking-[0.1em] text-muted hover:text-primary transition-colors">
                    
                          Edit
                        </button>
                        <button
                    onClick={() => setDeleteConfirm(item.id)}
                    className="flex-1 py-2 rounded-full bg-cream-dark hover:bg-red-50 text-xs font-bold uppercase tracking-[0.1em] text-muted hover:text-red-600 transition-colors">
                    
                          Delete
                        </button>
                      </div>
                    </div>
                  </div>
            )
            }
            </div>
          }
        </div>
      </main>

      {/* Add/Edit Modal */}
      {modalOpen &&
      <ItemModal
        item={editItem}
        onClose={() => {setModalOpen(false);setEditItem(null);}}
        onSave={handleSave} />

      }

      {/* Delete Confirm Modal */}
      {deleteConfirm !== null &&
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-dark/60 backdrop-blur-sm" onClick={() => setDeleteConfirm(null)} />
          <div className="relative bg-background rounded-3xl shadow-2xl p-8 max-w-sm w-full">
            <div className="w-14 h-14 rounded-full bg-red-50 flex items-center justify-center mx-auto mb-5">
              <svg className="w-7 h-7 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
              </svg>
            </div>
            <h3 className="font-display text-xl font-medium text-foreground text-center mb-2">Delete Item?</h3>
            <p className="text-muted text-sm text-center mb-6">This action cannot be undone. The item will be permanently removed from inventory.</p>
            <div className="flex gap-3">
              <button onClick={() => setDeleteConfirm(null)} className="flex-1 py-3 rounded-full border border-[var(--color-border)] text-[13px] font-bold uppercase tracking-[0.12em] text-muted hover:text-foreground transition-colors">
                Cancel
              </button>
              <button onClick={() => handleDelete(deleteConfirm)} className="flex-1 py-3 rounded-full bg-red-600 text-white text-[13px] font-bold uppercase tracking-[0.12em] hover:bg-red-700 transition-colors">
                Delete
              </button>
            </div>
          </div>
        </div>
      }

      <Footer />
    </>);

}
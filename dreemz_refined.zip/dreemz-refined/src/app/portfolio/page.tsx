'use client';

import React, { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import AppImage from '@/components/ui/AppImage';

type ProjectCategory = 'All' | 'Residential' | 'Commercial' | 'Exterior' | 'Hospitality';

interface Project {
  id: number;
  title: string;
  category: Exclude<ProjectCategory, 'All'>;
  location: string;
  year: string;
  client: string;
  area: string;
  budget: string;
  duration: string;
  description: string;
  tags: string[];
  image: string;
  alt: string;
  gallery: {src: string;alt: string;}[];
  featured: boolean;
}

const projects: Project[] = [
{
  id: 1,
  title: 'Lekki Phase 1 Penthouse',
  category: 'Residential',
  location: 'Lagos, Nigeria',
  year: '2025',
  client: 'Private Client',
  area: '450 m²',
  budget: '₦85M+',
  duration: '6 months',
  description: 'A breathtaking penthouse transformation featuring floor-to-ceiling windows, custom Italian marble surfaces, and a bespoke furniture collection curated from across Europe and West Africa. The design celebrates the intersection of contemporary luxury and Nigerian cultural heritage.',
  tags: ['Luxury', 'Penthouse', 'Custom Furniture', 'Marble'],
  image: 'https://img.rocket.new/generatedImages/rocket_gen_img_15fed27fb-1772893766018.png',
  alt: 'Modern penthouse living room with floor-to-ceiling windows and luxury furniture in Lagos',
  gallery: [
  { src: "https://img.rocket.new/generatedImages/rocket_gen_img_1264448d4-1772589659155.png", alt: 'Penthouse living area with panoramic city views' },
  { src: "https://img.rocket.new/generatedImages/rocket_gen_img_1173f80e8-1764853643873.png", alt: 'Master bedroom with custom upholstered headboard' },
  { src: "https://images.unsplash.com/photo-1723470915798-05ba9e611db8", alt: 'Open-plan kitchen and dining area' }],

  featured: true
},
{
  id: 2,
  title: 'Victoria Island Office Suite',
  category: 'Commercial',
  location: 'Lagos, Nigeria',
  year: '2025',
  client: 'Apex Financial Group',
  area: '280 m²',
  budget: '₦42M',
  duration: '4 months',
  description: 'A sophisticated corporate environment designed to inspire productivity and impress clients. Warm wood tones, curated art pieces, and ergonomic workstations create a space that balances professionalism with comfort.',
  tags: ['Corporate', 'Office', 'Biophilic Design', 'Ergonomics'],
  image: "https://images.unsplash.com/photo-1655745653127-4d6837baf958",
  alt: 'Contemporary office interior with warm wood tones and modern workstations',
  gallery: [
  { src: "https://img.rocket.new/generatedImages/rocket_gen_img_131026ce1-1772198523736.png", alt: 'Executive boardroom with custom conference table' },
  { src: "https://img.rocket.new/generatedImages/rocket_gen_img_100a29a43-1768384099551.png", alt: 'Open workspace with collaborative zones' }],

  featured: false
},
{
  id: 3,
  title: 'Maitama Villa Bedroom',
  category: 'Residential',
  location: 'Abuja, Nigeria',
  year: '2024',
  client: 'Private Client',
  area: '85 m²',
  budget: '₦18M',
  duration: '2 months',
  description: 'A serene master bedroom sanctuary featuring a custom upholstered headboard, bespoke wardrobes, and a carefully curated palette of ivory, sage, and warm gold that evokes calm and luxury.',
  tags: ['Bedroom', 'Bespoke', 'Luxury', 'Sanctuary'],
  image: 'https://img.rocket.new/generatedImages/rocket_gen_img_1cbe95b3f-1772893765660.png',
  alt: 'Luxury master bedroom with upholstered headboard and ambient lighting in Abuja villa',
  gallery: [
  { src: "https://images.unsplash.com/photo-1700074999121-c0b48142a57e", alt: 'En-suite bathroom with freestanding tub' },
  { src: "https://img.rocket.new/generatedImages/rocket_gen_img_1a6bc5f5e-1772135767737.png", alt: 'Walk-in wardrobe with custom joinery' }],

  featured: false
},
{
  id: 4,
  title: 'Ikoyi Dining Experience',
  category: 'Residential',
  location: 'Lagos, Nigeria',
  year: '2024',
  client: 'Private Client',
  area: '60 m²',
  budget: '₦12M',
  duration: '6 weeks',
  description: 'An intimate dining room designed for memorable gatherings. A custom 10-seater table in solid walnut anchors the space, while a dramatic chandelier and curated art collection create an atmosphere of refined elegance.',
  tags: ['Dining', 'Custom Furniture', 'Lighting', 'Art Curation'],
  image: "https://images.unsplash.com/photo-1672630488350-f7990421e358",
  alt: 'Elegant dining room with custom table and statement chandelier in Ikoyi home',
  gallery: [
  { src: "https://img.rocket.new/generatedImages/rocket_gen_img_1077ae7c8-1772161005455.png", alt: 'Close-up of custom walnut dining table setting' }],

  featured: false
},
{
  id: 5,
  title: 'Asokoro Exterior Landscape',
  category: 'Exterior',
  location: 'Abuja, Nigeria',
  year: '2025',
  client: 'Private Client',
  area: '1,200 m²',
  budget: '₦55M',
  duration: '5 months',
  description: 'A comprehensive exterior transformation encompassing facade redesign, landscaping, outdoor entertainment areas, and a resort-style pool deck. The design harmonizes with the natural terrain while creating distinct zones for relaxation and entertainment.',
  tags: ['Landscape', 'Pool', 'Facade', 'Outdoor Living'],
  image: 'https://img.rocket.new/generatedImages/rocket_gen_img_13dc422ac-1772210226514.png',
  alt: 'Beautiful exterior landscaping and facade design of luxury home in Abuja',
  gallery: [
  { src: "https://images.unsplash.com/photo-1652400096233-90b866acc135", alt: 'Pool deck with outdoor lounge furniture' },
  { src: "https://images.unsplash.com/photo-1600865207482-6bcd6a4a84ab", alt: 'Garden pathway with landscape lighting' }],

  featured: true
},
{
  id: 6,
  title: 'Eko Hotel Lobby Refresh',
  category: 'Hospitality',
  location: 'Lagos, Nigeria',
  year: '2024',
  client: 'Eko Hotels & Suites',
  area: '620 m²',
  budget: '₦120M',
  duration: '8 months',
  description: 'A landmark hospitality project that reimagines the arrival experience. Rich Nigerian textiles, hand-crafted sculptures, and a dramatic double-height atrium create an unforgettable first impression that celebrates African luxury.',
  tags: ['Hotel', 'Lobby', 'African Luxury', 'Atrium'],
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_15af5a251-1766773680634.png",
  alt: 'Luxurious hotel lobby with African art installations and dramatic lighting',
  gallery: [
  { src: "https://images.unsplash.com/photo-1615618922256-74849f143904", alt: 'Hotel reception desk with custom marble counter' },
  { src: "https://images.unsplash.com/photo-1699357615684-3ad81d354d6c", alt: 'Lobby lounge seating area with curated art' }],

  featured: true
},
{
  id: 7,
  title: 'Banana Island Smart Home',
  category: 'Residential',
  location: 'Lagos, Nigeria',
  year: '2025',
  client: 'Private Client',
  area: '780 m²',
  budget: '₦160M+',
  duration: '10 months',
  description: 'A fully integrated smart home where technology and design coexist seamlessly. Automated lighting, climate control, and entertainment systems are embedded within a design language of understated luxury and timeless elegance.',
  tags: ['Smart Home', 'Technology', 'Luxury', 'Full Home'],
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1d39a62c6-1771886715964.png",
  alt: 'Modern smart home living room with integrated technology and luxury finishes',
  gallery: [
  { src: "https://img.rocket.new/generatedImages/rocket_gen_img_16e89885a-1769516338661.png", alt: 'Smart home control panel integrated into wall' }],

  featured: false
},
{
  id: 8,
  title: 'Wuse II Restaurant Interior',
  category: 'Hospitality',
  location: 'Abuja, Nigeria',
  year: '2024',
  client: 'Saveur Restaurant Group',
  area: '340 m²',
  budget: '₦38M',
  duration: '3 months',
  description: 'A contemporary fine dining environment that draws inspiration from West African craft traditions. Handmade ceramic tiles, woven wall panels, and custom lighting create an atmosphere that is both intimate and celebratory.',
  tags: ['Restaurant', 'Fine Dining', 'Craft', 'Ambiance'],
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_15b57c96c-1772279318637.png",
  alt: 'Elegant restaurant interior with warm lighting and handcrafted decor elements',
  gallery: [
  { src: "https://img.rocket.new/generatedImages/rocket_gen_img_1e32ea83d-1768221831442.png", alt: 'Restaurant bar area with custom backlit shelving' }],

  featured: false
}];


const categoryFilters: ProjectCategory[] = ['All', 'Residential', 'Commercial', 'Exterior', 'Hospitality'];

const categoryColors: Record<Exclude<ProjectCategory, 'All'>, string> = {
  Residential: 'text-blue-700 bg-blue-50 border-blue-200',
  Commercial: 'text-purple-700 bg-purple-50 border-purple-200',
  Exterior: 'text-green-700 bg-green-50 border-green-200',
  Hospitality: 'text-amber-700 bg-amber-50 border-amber-200'
};

interface ProjectModalProps {
  project: Project;
  onClose: () => void;
}

function ProjectModal({ project, onClose }: ProjectModalProps) {
  const [activeImg, setActiveImg] = useState(0);
  const allImages = [{ src: project.image, alt: project.alt }, ...project.gallery];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-dark/70 backdrop-blur-sm" />
      <div
        className="relative bg-background rounded-3xl shadow-2xl w-full max-w-4xl max-h-[92vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}>
        
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 z-10 w-10 h-10 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center hover:bg-white transition-colors shadow-md">
          
          <svg className="w-5 h-5 text-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        {/* Main Image */}
        <div className="relative h-72 md:h-96 rounded-t-3xl overflow-hidden">
          <AppImage
            src={allImages[activeImg]?.src}
            alt={allImages[activeImg]?.alt}
            fill
            className="object-cover"
            sizes="(max-width: 768px) 100vw, 896px" />
          
          <div className="absolute inset-0 bg-gradient-to-t from-dark/60 to-transparent" />
          <div className="absolute bottom-6 left-8">
            <span className={`text-xs font-semibold px-3 py-1.5 rounded-full border ${categoryColors[project.category]} mb-3 inline-block`}>
              {project.category}
            </span>
            <h2 className="font-display text-3xl font-medium text-white">{project.title}</h2>
            <p className="text-white/70 text-sm mt-1">{project.location} · {project.year}</p>
          </div>
        </div>

        {/* Thumbnail strip */}
        {allImages.length > 1 &&
        <div className="flex gap-2 px-8 py-4 bg-cream-dark border-b border-[var(--color-border)]">
            {allImages.map((img, i) =>
          <button
            key={i}
            onClick={() => setActiveImg(i)}
            className={`relative w-16 h-12 rounded-xl overflow-hidden flex-shrink-0 transition-all ${activeImg === i ? 'ring-2 ring-primary' : 'opacity-60 hover:opacity-100'}`}>
            
                <AppImage src={img.src} alt={img.alt} fill className="object-cover" sizes="64px" />
              </button>
          )}
          </div>
        }

        {/* Details */}
        <div className="p-8">
          {/* Stats grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {[
            { label: 'Area', value: project.area },
            { label: 'Budget', value: project.budget },
            { label: 'Duration', value: project.duration },
            { label: 'Client', value: project.client }].
            map((stat) =>
            <div key={stat.label} className="bg-cream-dark rounded-2xl p-4">
                <div className="text-[10px] font-bold uppercase tracking-[0.18em] text-muted mb-1">{stat.label}</div>
                <div className="font-semibold text-foreground text-sm">{stat.value}</div>
              </div>
            )}
          </div>

          {/* Description */}
          <p className="text-muted leading-relaxed mb-6">{project.description}</p>

          {/* Tags */}
          <div className="flex flex-wrap gap-2">
            {project.tags.map((tag) =>
            <span key={tag} className="text-xs font-semibold px-3 py-1.5 rounded-full bg-cream-dark text-muted border border-[var(--color-border)]">
                {tag}
              </span>
            )}
          </div>
        </div>
      </div>
    </div>);

}

export default function PortfolioPage() {
  const [activeCategory, setActiveCategory] = useState<ProjectCategory>('All');
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) entry.target.classList.add('revealed');
        });
      },
      { threshold: 0.1 }
    );
    const els = sectionRef.current?.querySelectorAll('.scroll-reveal, .stagger-children');
    els?.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const filtered = activeCategory === 'All' ?
  projects :
  projects.filter((p) => p.category === activeCategory);

  const featured = filtered.filter((p) => p.featured);
  const regular = filtered.filter((p) => !p.featured);

  const stats = [
  { value: '120+', label: 'Projects Completed' },
  { value: '8', label: 'Years of Excellence' },
  { value: '₦2B+', label: 'Projects Delivered' },
  { value: '98%', label: 'Client Satisfaction' }];


  return (
    <>
      <Header />
      <main className="min-h-screen bg-background">

        {/* Hero */}
        <section className="relative pt-36 pb-20 px-6 md:px-10 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-cream-dark via-background to-background" />
          <div className="absolute top-0 right-0 w-[600px] h-[600px] rounded-full bg-primary/5 blur-3xl -translate-y-1/2 translate-x-1/4" />

          <div ref={sectionRef} className="max-w-7xl mx-auto relative">
            <div className="scroll-reveal mb-4 flex items-center gap-3">
              <Link href="/homepage" className="text-muted text-sm hover:text-foreground transition-colors">Home</Link>
              <span className="text-muted/40">›</span>
              <span className="text-sm text-foreground font-medium">Portfolio</span>
            </div>

            <div className="scroll-reveal max-w-3xl mb-16">
              <span className="section-tag mb-4">Our Work</span>
              <h1 className="font-display text-[clamp(2.8rem,6vw,6rem)] font-light leading-[1.05] tracking-display text-foreground mb-6">
                Spaces that{' '}
                <span className="italic text-primary">inspire</span>
                <br />& endure
              </h1>
              <p className="text-lg text-muted leading-relaxed max-w-xl">
                From intimate residential sanctuaries to landmark commercial spaces — every project is a testament to our commitment to craft, beauty, and lasting impact.
              </p>
            </div>

            {/* Stats */}
            <div className="stagger-children grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
              {stats.map((stat) =>
              <div key={stat.label} className="border-l-2 border-primary pl-5">
                  <div className="font-display text-3xl md:text-4xl font-medium text-foreground">{stat.value}</div>
                  <div className="text-sm text-muted mt-1">{stat.label}</div>
                </div>
              )}
            </div>

            {/* Category Filters */}
            <div className="scroll-reveal flex flex-wrap gap-3 mb-12">
              {categoryFilters.map((cat) =>
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-5 py-2.5 rounded-full text-[12px] font-bold uppercase tracking-[0.15em] transition-all duration-300 ${
                activeCategory === cat ?
                'bg-foreground text-white shadow-md' :
                'bg-cream-dark text-muted hover:text-foreground hover:bg-cream-darker'}`
                }>
                
                  {cat}
                  {cat !== 'All' &&
                <span className="ml-2 opacity-60">
                      ({projects.filter((p) => p.category === cat).length})
                    </span>
                }
                </button>
              )}
            </div>

            {/* Featured Projects */}
            {featured.length > 0 &&
            <div className="mb-8">
                <div className="flex items-center gap-3 mb-6">
                  <span className="section-tag">Featured</span>
                </div>
                <div className="stagger-children grid grid-cols-1 md:grid-cols-2 gap-5 mb-5">
                  {featured.map((project) =>
                <div
                  key={project.id}
                  onClick={() => setSelectedProject(project)}
                  className="img-zoom rounded-3xl overflow-hidden relative group cursor-pointer"
                  style={{ minHeight: '380px' }}>
                  
                      <AppImage
                    src={project.image}
                    alt={project.alt}
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 100vw, 50vw" />
                  
                      <div className="absolute inset-0 bg-gradient-to-t from-dark/85 via-dark/20 to-transparent" />
                      <div className="absolute top-5 left-5">
                        <span className={`text-xs font-semibold px-3 py-1.5 rounded-full border ${categoryColors[project.category]}`}>
                          {project.category}
                        </span>
                      </div>
                      <div className="absolute top-5 right-5 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                          <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                          </svg>
                        </div>
                      </div>
                      <div className="absolute bottom-0 left-0 right-0 p-8 translate-y-2 group-hover:translate-y-0 transition-transform duration-400">
                        <h3 className="font-display text-2xl font-medium text-white mb-1">{project.title}</h3>
                        <p className="text-white/60 text-sm mb-3">{project.location} · {project.year}</p>
                        <div className="flex flex-wrap gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                          {project.tags.slice(0, 3).map((tag) =>
                      <span key={tag} className="text-xs px-2.5 py-1 rounded-full bg-white/15 text-white/80">{tag}</span>
                      )}
                        </div>
                      </div>
                    </div>
                )}
                </div>
              </div>
            }

            {/* Regular Projects Grid */}
            {regular.length > 0 &&
            <div>
                {featured.length > 0 &&
              <div className="flex items-center gap-3 mb-6">
                    <span className="section-tag">All Projects</span>
                  </div>
              }
                <div className="stagger-children grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                  {regular.map((project) =>
                <div
                  key={project.id}
                  onClick={() => setSelectedProject(project)}
                  className="img-zoom rounded-3xl overflow-hidden relative group cursor-pointer"
                  style={{ minHeight: '280px' }}>
                  
                      <AppImage
                    src={project.image}
                    alt={project.alt}
                    fill
                    className="object-cover"
                    sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw" />
                  
                      <div className="absolute inset-0 bg-gradient-to-t from-dark/80 via-dark/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-400" />
                      <div className="absolute top-4 left-4">
                        <span className={`text-xs font-semibold px-2.5 py-1 rounded-full border ${categoryColors[project.category]}`}>
                          {project.category}
                        </span>
                      </div>
                      <div className="absolute bottom-0 left-0 right-0 p-6 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-400">
                        <h3 className="font-display text-lg font-medium text-white">{project.title}</h3>
                        <p className="text-white/60 text-xs mt-0.5">{project.location} · {project.year}</p>
                      </div>
                    </div>
                )}
                </div>
              </div>
            }

            {filtered.length === 0 &&
            <div className="text-center py-20 text-muted">
                <div className="text-5xl mb-4">🎨</div>
                <div className="font-display text-xl font-medium text-foreground mb-2">No projects in this category yet</div>
                <div className="text-sm">Check back soon for new additions</div>
              </div>
            }

            {/* CTA */}
            <div className="scroll-reveal mt-20 bg-foreground rounded-3xl p-10 md:p-14 text-center">
              <span className="section-tag mb-4 justify-center" style={{ color: 'var(--color-primary)' }}>Start Your Project</span>
              <h2 className="font-display text-[clamp(1.8rem,4vw,3.5rem)] font-light text-white leading-tight mb-4">
                Ready to transform your space?
              </h2>
              <p className="text-white/60 max-w-md mx-auto mb-8 leading-relaxed">
                Let&apos;s discuss your vision and create something extraordinary together.
              </p>
              <Link
                href="/homepage#contact"
                className="btn-gold inline-flex items-center gap-2 px-8 py-4 rounded-full text-[13px] font-bold uppercase tracking-[0.12em]">
                
                Book a Consultation
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                </svg>
              </Link>
            </div>
          </div>
        </section>
      </main>

      {/* Project Detail Modal */}
      {selectedProject &&
      <ProjectModal project={selectedProject} onClose={() => setSelectedProject(null)} />
      }

      <Footer />
    </>);

}
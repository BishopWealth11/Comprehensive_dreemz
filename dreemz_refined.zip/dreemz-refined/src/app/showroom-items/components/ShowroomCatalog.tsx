'use client';

import React, { useState, useMemo, useRef, useEffect } from 'react';
import Link from 'next/link';
import AppImage from '@/components/ui/AppImage';

interface ShowroomItem {
  id: number;
  name: string;
  category: string;
  subcategory: string;
  price: number;
  originalPrice: number | null;
  image: string;
  alt: string;
  badge: string | null;
  available: boolean;
  inStock: number;
  description: string;
  dimensions: string;
  material: string;
  color: string;
  sku: string;
  featured: boolean;
}

const allItems: ShowroomItem[] = [
{
  id: 1,
  name: 'Castello L-Shaped Sectional Sofa',
  category: 'Living Room',
  subcategory: 'Sofas',
  price: 2850000,
  originalPrice: 3200000,
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_168cb50c7-1772355321684.png",
  alt: 'Modern grey L-shaped sectional sofa with deep cushions and clean lines',
  badge: 'Bestseller',
  available: true,
  inStock: 3,
  description: 'Premium fabric sectional with modular configuration. Ideal for open-plan living spaces.',
  dimensions: '320cm x 200cm x 85cm',
  material: 'Linen fabric, solid hardwood frame',
  color: 'Warm Grey',
  sku: 'DRZ-LR-001',
  featured: true
},
{
  id: 2,
  name: 'Meridian King Upholstered Bed',
  category: 'Bedroom',
  subcategory: 'Beds',
  price: 1950000,
  originalPrice: null,
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1b7259e54-1773090346501.png",
  alt: 'Upholstered king size bed frame with tufted headboard in cream fabric',
  badge: 'New Arrival',
  available: true,
  inStock: 5,
  description: 'Luxurious king bed with deep-tufted headboard. Upholstered in premium cream boucle fabric.',
  dimensions: '220cm x 200cm x 140cm (headboard)',
  material: 'Boucle fabric, engineered wood base',
  color: 'Ivory Cream',
  sku: 'DRZ-BD-001',
  featured: true
},
{
  id: 3,
  name: 'Artisan 8-Seater Dining Table',
  category: 'Dining',
  subcategory: 'Tables',
  price: 1680000,
  originalPrice: 1900000,
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_17e95032f-1772864330048.png",
  alt: 'Solid wood dining table with metal base for eight persons',
  badge: null,
  available: true,
  inStock: 4,
  description: 'Handcrafted solid teak dining table with a powder-coated matte black steel base.',
  dimensions: '240cm x 100cm x 76cm',
  material: 'Solid teak wood, powder-coated steel',
  color: 'Natural Teak / Black',
  sku: 'DRZ-DIN-001',
  featured: false
},
{
  id: 4,
  name: 'Luxe Executive Office Chair',
  category: 'Office',
  subcategory: 'Seating',
  price: 420000,
  originalPrice: null,
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1562f2b95-1772115480185.png",
  alt: 'Premium leather executive office chair with lumbar support',
  badge: 'Limited Stock',
  available: true,
  inStock: 8,
  description: 'Full-grain leather executive chair with adjustable lumbar support, armrests, and 5-star base.',
  dimensions: '70cm x 70cm x 120-130cm (adjustable)',
  material: 'Full-grain leather, chrome base',
  color: 'Cognac Brown',
  sku: 'DRZ-OF-001',
  featured: false
},
{
  id: 5,
  name: 'Nordic Floor Lamp — Brass',
  category: 'Lighting',
  subcategory: 'Floor Lamps',
  price: 185000,
  originalPrice: 220000,
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_14b0deb93-1773059150910.png",
  alt: 'Elegant brass floor lamp with white linen shade for living room',
  badge: null,
  available: true,
  inStock: 12,
  description: 'Minimalist brass floor lamp with adjustable linen shade. Perfect accent for reading corners.',
  dimensions: '38cm x 38cm x 165cm',
  material: 'Solid brass, linen shade',
  color: 'Antique Brass',
  sku: 'DRZ-LGT-001',
  featured: false
},
{
  id: 6,
  name: 'Velvet Accent Chair — Emerald',
  category: 'Living Room',
  subcategory: 'Chairs',
  price: 680000,
  originalPrice: null,
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_15ca3d9ba-1772220157825.png",
  alt: 'Emerald green velvet accent chair with gold legs',
  badge: 'New Arrival',
  available: true,
  inStock: 6,
  description: 'Statement accent chair in rich emerald velvet. Gold-tipped legs add a touch of opulence.',
  dimensions: '80cm x 75cm x 85cm',
  material: 'Velvet upholstery, gold-finished legs',
  color: 'Emerald Green',
  sku: 'DRZ-LR-002',
  featured: true
},
{
  id: 7,
  name: 'Marble Top Coffee Table',
  category: 'Living Room',
  subcategory: 'Tables',
  price: 890000,
  originalPrice: 1050000,
  image: "https://images.unsplash.com/photo-1613235116556-94a5ca9c799b",
  alt: 'Round marble top coffee table with brass base in luxury living room',
  badge: null,
  available: true,
  inStock: 7,
  description: 'Italian Carrara marble top with brushed brass pedestal base. A centrepiece for any living room.',
  dimensions: '90cm diameter x 42cm height',
  material: 'Carrara marble, brushed brass',
  color: 'White Marble / Brass',
  sku: 'DRZ-LR-003',
  featured: false
},
{
  id: 8,
  name: 'Rattan Outdoor Lounge Set',
  category: 'Outdoor',
  subcategory: 'Sets',
  price: 1350000,
  originalPrice: null,
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1bf7a0004-1767458841223.png",
  alt: 'Premium rattan outdoor lounge set with cushions for patio or garden',
  badge: null,
  available: true,
  inStock: 2,
  description: '5-piece outdoor lounge set in weather-resistant synthetic rattan. Includes cushions.',
  dimensions: 'Sofa: 180cm x 80cm | 2 chairs: 75cm x 75cm',
  material: 'Synthetic rattan, powder-coated aluminium',
  color: 'Natural / Cream Cushions',
  sku: 'DRZ-OUT-001',
  featured: false
},
{
  id: 9,
  name: 'Wardrobe — Walnut Finish',
  category: 'Bedroom',
  subcategory: 'Storage',
  price: 2200000,
  originalPrice: null,
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_180a201bf-1772601616313.png",
  alt: 'Six-door wardrobe with walnut finish and soft-close hinges',
  badge: null,
  available: true,
  inStock: 3,
  description: '6-door sliding wardrobe with walnut veneer finish. Includes internal shelving, hanging rails, and drawers.',
  dimensions: '300cm x 60cm x 240cm',
  material: 'Walnut veneer, soft-close hardware',
  color: 'Dark Walnut',
  sku: 'DRZ-BD-002',
  featured: false
},
{
  id: 10,
  name: 'Pendant Light — Woven Rattan',
  category: 'Lighting',
  subcategory: 'Pendants',
  price: 95000,
  originalPrice: 115000,
  image: "https://images.unsplash.com/photo-1687089117947-20664d9b2f5f",
  alt: 'Handwoven rattan pendant light for dining room or kitchen island',
  badge: null,
  available: true,
  inStock: 20,
  description: 'Handwoven natural rattan pendant. Ideal over dining tables or kitchen islands.',
  dimensions: '50cm diameter x 40cm height',
  material: 'Natural rattan, cotton cord',
  color: 'Natural Rattan',
  sku: 'DRZ-LGT-002',
  featured: false
},
{
  id: 11,
  name: 'Bookcase — Oak & Brass',
  category: 'Office',
  subcategory: 'Storage',
  price: 760000,
  originalPrice: null,
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_18828e3c0-1773666244287.png",
  alt: 'Open bookcase with oak shelves and brass frame for home office',
  badge: null,
  available: false,
  inStock: 0,
  description: 'Open-back bookcase with solid oak shelves and brass-finished steel frame. 6 adjustable shelves.',
  dimensions: '100cm x 35cm x 200cm',
  material: 'Solid oak, brass-finished steel',
  color: 'Natural Oak / Brass',
  sku: 'DRZ-OF-002',
  featured: false
},
{
  id: 12,
  name: 'Dining Chairs — Set of 6',
  category: 'Dining',
  subcategory: 'Chairs',
  price: 840000,
  originalPrice: 960000,
  image: "https://images.unsplash.com/photo-1664122073255-dab8f6a991a4",
  alt: 'Set of six upholstered dining chairs in sage green velvet with gold legs',
  badge: 'Bundle Deal',
  available: true,
  inStock: 4,
  description: 'Set of 6 upholstered dining chairs in sage green velvet. Gold-finished metal legs.',
  dimensions: '50cm x 55cm x 90cm each',
  material: 'Velvet, gold-finished metal',
  color: 'Sage Green',
  sku: 'DRZ-DIN-002',
  featured: false
}];


const categories = ['All', 'Living Room', 'Bedroom', 'Dining', 'Office', 'Lighting', 'Outdoor'];
const sortOptions = [
{ value: 'featured', label: 'Featured First' },
{ value: 'price-asc', label: 'Price: Low to High' },
{ value: 'price-desc', label: 'Price: High to Low' },
{ value: 'name-asc', label: 'Name: A–Z' },
{ value: 'stock', label: 'In Stock First' }];


const formatNGN = (amount: number) => `₦${amount.toLocaleString('en-NG')}`;

interface QuickViewItem extends ShowroomItem {}

export default function ShowroomCatalog() {
  const [activeCategory, setActiveCategory] = useState('All');
  const [sortBy, setSortBy] = useState('featured');
  const [searchQuery, setSearchQuery] = useState('');
  const [quickViewItem, setQuickViewItem] = useState<QuickViewItem | null>(null);
  const [showOnlyAvailable, setShowOnlyAvailable] = useState(false);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 3500000]);
  const [showFilters, setShowFilters] = useState(false);
  const catalogRef = useRef<HTMLDivElement>(null);

  // Scroll reveal
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('revealed');
          }
        });
      },
      { threshold: 0.05 }
    );
    const elements = catalogRef.current?.querySelectorAll('.scroll-reveal, .stagger-children');
    elements?.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const filteredItems = useMemo(() => {
    let items = [...allItems];

    // Category filter
    if (activeCategory !== 'All') {
      items = items.filter((item) => item.category === activeCategory);
    }

    // Search
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      items = items.filter(
        (item) =>
        item.name.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        item.color.toLowerCase().includes(q)
      );
    }

    // Availability
    if (showOnlyAvailable) {
      items = items.filter((item) => item.available && item.inStock > 0);
    }

    // Price range
    items = items.filter((item) => item.price >= priceRange[0] && item.price <= priceRange[1]);

    // Sort
    switch (sortBy) {
      case 'price-asc':
        items.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        items.sort((a, b) => b.price - a.price);
        break;
      case 'name-asc':
        items.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'stock':
        items.sort((a, b) => b.inStock - a.inStock);
        break;
      case 'featured':
      default:
        items.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
        break;
    }

    return items;
  }, [activeCategory, searchQuery, showOnlyAvailable, priceRange, sortBy]);

  return (
    <div ref={catalogRef} className="pt-24 min-h-screen bg-background">
      {/* Page Hero */}
      <div className="bg-cream-dark border-b border-[var(--color-border)] px-6 md:px-10 py-14 md:py-20">
        <div className="max-w-7xl mx-auto">
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-[12px] font-semibold uppercase tracking-[0.15em] text-muted mb-6 scroll-reveal">
            <Link href="/homepage" className="hover:text-foreground transition-colors">Home</Link>
            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
            <span className="text-foreground">Showroom</span>
          </div>

          <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 scroll-reveal">
            <div>
              <span className="section-tag mb-4">Showroom Catalog</span>
              <h1 className="font-display text-[clamp(2.4rem,5vw,5rem)] font-light leading-[1.05] tracking-tightest text-foreground">
                Premium Furniture{' '}
                <br className="hidden md:block" />
                <span className="italic text-primary">&amp; Décor</span>
              </h1>
            </div>
            <p className="max-w-sm text-base text-muted leading-relaxed">
              {filteredItems.length} item{filteredItems.length !== 1 ? 's' : ''} available · All prices in Nigerian Naira (₦)
            </p>
          </div>
        </div>
      </div>

      {/* Search + Filters Bar */}
      <div className="sticky top-[60px] z-40 bg-background/95 backdrop-blur-md border-b border-[var(--color-border)] px-6 md:px-10 py-4">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
          {/* Search */}
          <div className="relative flex-1 max-w-md">
            <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <input
              type="text"
              placeholder="Search furniture, décor..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-11 pr-4 py-2.5 rounded-full border border-[var(--color-border)] bg-cream-dark text-sm focus:outline-none focus:border-primary transition-colors placeholder:text-muted-light" />
            
            {searchQuery &&
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-muted hover:text-foreground">
              
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            }
          </div>

          {/* Right controls */}
          <div className="flex items-center gap-3">
            {/* Sort */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-4 py-2.5 rounded-full border border-[var(--color-border)] bg-cream-dark text-sm font-medium text-muted focus:outline-none focus:border-primary transition-colors cursor-pointer appearance-none pr-8">
              
              {sortOptions.map((opt) =>
              <option key={opt.value} value={opt.value}>{opt.label}</option>
              )}
            </select>

            {/* Filters toggle */}
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-full border text-sm font-medium transition-all duration-200 ${
              showFilters ?
              'bg-foreground border-foreground text-white' :
              'border-[var(--color-border)] text-muted hover:border-foreground hover:text-foreground'}`
              }>
              
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
              </svg>
              Filters
            </button>
          </div>
        </div>

        {/* Expanded filters */}
        {showFilters &&
        <div className="max-w-7xl mx-auto pt-4 pb-2 flex flex-wrap gap-4 items-center border-t border-[var(--color-border)] mt-4">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
              type="checkbox"
              checked={showOnlyAvailable}
              onChange={(e) => setShowOnlyAvailable(e.target.checked)}
              className="w-4 h-4 accent-primary rounded" />
            
              <span className="text-sm font-medium text-muted">In Stock Only</span>
            </label>
            <div className="flex items-center gap-3">
              <span className="text-sm text-muted font-medium">Price:</span>
              <span className="text-sm font-bold text-foreground">
                {formatNGN(priceRange[0])} — {formatNGN(priceRange[1])}
              </span>
              <input
              type="range"
              min={0}
              max={3500000}
              step={50000}
              value={priceRange[1]}
              onChange={(e) => setPriceRange([priceRange[0], Number(e.target.value)])}
              className="w-32 accent-primary" />
            
            </div>
          </div>
        }
      </div>

      <div className="max-w-7xl mx-auto px-6 md:px-10 py-10">
        {/* Category chips */}
        <div className="flex gap-3 flex-wrap mb-10 scroll-reveal">
          {categories.map((cat) =>
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`filter-chip ${activeCategory === cat ? 'gold-active' : ''}`}>
            
              {cat}
            </button>
          )}
        </div>

        {/* Results count */}
        {(searchQuery || activeCategory !== 'All' || showOnlyAvailable) &&
        <div className="mb-6 flex items-center gap-3">
            <span className="text-sm text-muted">
              Showing <span className="font-bold text-foreground">{filteredItems.length}</span> result{filteredItems.length !== 1 ? 's' : ''}
              {activeCategory !== 'All' && ` in ${activeCategory}`}
              {searchQuery && ` for "${searchQuery}"`}
            </span>
            <button
            onClick={() => {setActiveCategory('All');setSearchQuery('');setShowOnlyAvailable(false);setPriceRange([0, 3500000]);}}
            className="text-xs font-bold text-primary hover:text-primary-dark underline transition-colors">
            
              Clear all
            </button>
          </div>
        }

        {/* Product Grid */}
        {filteredItems.length === 0 ?
        <div className="text-center py-24">
            <div className="w-20 h-20 rounded-full bg-cream-dark flex items-center justify-center mx-auto mb-6">
              <svg className="w-10 h-10 text-muted-light" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h3 className="font-display text-2xl font-medium text-foreground mb-3">No items found</h3>
            <p className="text-muted mb-6">Try adjusting your filters or search term.</p>
            <button
            onClick={() => {setActiveCategory('All');setSearchQuery('');setShowOnlyAvailable(false);}}
            className="btn-gold px-8 py-3 rounded-full text-sm font-bold uppercase tracking-[0.12em]">
            
              Reset Filters
            </button>
          </div> :

        <div className="stagger-children grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredItems.map((item) =>
          <div
            key={item.id}
            className="product-card group flex flex-col">
            
                {/* Image */}
                <div className="relative overflow-hidden" style={{ height: '280px' }}>
                  <AppImage
                src={item.image}
                alt={item.alt}
                fill
                className="object-cover transition-transform duration-700 group-hover:scale-105"
                sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw" />
              

                  {/* Badges */}
                  <div className="absolute top-4 left-4 flex flex-col gap-2">
                    {item.badge &&
                <span className="badge-gold">{item.badge}</span>
                }
                    {!item.available || item.inStock === 0 ?
                <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-[0.1em] bg-gray-900/80 text-white">
                        Out of Stock
                      </span> :
                item.inStock <= 3 ?
                <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-[0.1em] bg-red-600/90 text-white">
                        Only {item.inStock} left
                      </span> :
                null}
                  </div>

                  {/* Hover overlay */}
                  <div className="absolute inset-0 bg-dark/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-3">
                    <button
                  onClick={() => setQuickViewItem(item)}
                  className="bg-white text-foreground px-5 py-2.5 rounded-full text-[12px] font-bold uppercase tracking-[0.1em] hover:bg-primary transition-colors duration-200 flex items-center gap-2">
                  
                      <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                      </svg>
                      Quick View
                    </button>
                  </div>
                </div>

                {/* Info */}
                <div className="p-5 flex flex-col flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[11px] font-bold uppercase tracking-[0.15em] text-primary">
                      {item.category}
                    </span>
                    <span className="text-[11px] font-mono text-muted-light">
                      {item.sku}
                    </span>
                  </div>

                  <h2 className="font-display text-lg font-medium text-foreground mb-2 leading-tight flex-1">
                    {item.name}
                  </h2>

                  <p className="text-sm text-muted leading-relaxed mb-4 line-clamp-2">
                    {item.description}
                  </p>

                  {/* Color + material chips */}
                  <div className="flex gap-2 flex-wrap mb-4">
                    <span className="text-[11px] px-2.5 py-1 rounded-full bg-cream-dark text-muted font-medium">
                      {item.color}
                    </span>
                    <span className="text-[11px] px-2.5 py-1 rounded-full bg-cream-dark text-muted font-medium truncate max-w-[140px]">
                      {item.material.split(',')[0]}
                    </span>
                  </div>

                  {/* Price + CTA */}
                  <div className="flex items-center justify-between pt-4 border-t border-[var(--color-border)] mt-auto">
                    <div>
                      <div className={`text-xl font-bold ${item.available && item.inStock > 0 ? 'text-foreground' : 'text-muted-light'}`}>
                        {formatNGN(item.price)}
                      </div>
                      {item.originalPrice &&
                  <div className="text-sm text-muted line-through">
                          {formatNGN(item.originalPrice)}
                        </div>
                  }
                      {item.originalPrice &&
                  <div className="text-[11px] font-bold text-green-600">
                          Save {formatNGN(item.originalPrice - item.price)}
                        </div>
                  }
                    </div>

                    <button
                  onClick={() => setQuickViewItem(item)}
                  disabled={!item.available || item.inStock === 0}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-full text-[12px] font-bold uppercase tracking-[0.1em] transition-all duration-200 ${
                  item.available && item.inStock > 0 ?
                  'btn-gold' : 'bg-cream-dark text-muted-light cursor-not-allowed'}`
                  }>
                  
                      {item.available && item.inStock > 0 ? 'Enquire' : 'Sold Out'}
                    </button>
                  </div>
                </div>
              </div>
          )}
          </div>
        }

        {/* Load more / pagination placeholder */}
        {filteredItems.length > 0 &&
        <div className="mt-16 flex justify-center scroll-reveal">
            <div className="flex items-center gap-4">
              <div className="h-px w-16 bg-[var(--color-border)]" />
              <span className="text-sm text-muted font-medium">
                Showing all {filteredItems.length} items
              </span>
              <div className="h-px w-16 bg-[var(--color-border)]" />
            </div>
          </div>
        }
      </div>

      {/* Quick View Modal */}
      {quickViewItem &&
      <div
        className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-8"
        onClick={(e) => {if (e.target === e.currentTarget) setQuickViewItem(null);}}>
        
          {/* Backdrop */}
          <div className="absolute inset-0 bg-dark/60 backdrop-blur-sm" onClick={() => setQuickViewItem(null)} />

          {/* Modal */}
          <div className="relative bg-background rounded-3xl overflow-hidden shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto z-10">
            {/* Close */}
            <button
            onClick={() => setQuickViewItem(null)}
            className="absolute top-5 right-5 z-20 w-10 h-10 rounded-full bg-cream-dark border border-[var(--color-border)] flex items-center justify-center text-muted hover:text-foreground transition-colors"
            aria-label="Close quick view">
            
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>

            <div className="grid grid-cols-1 md:grid-cols-2">
              {/* Image */}
              <div className="relative" style={{ minHeight: '400px' }}>
                <AppImage
                src={quickViewItem.image}
                alt={quickViewItem.alt}
                fill
                className="object-cover"
                sizes="(max-width: 768px) 100vw, 50vw" />
              
                {quickViewItem.badge &&
              <div className="absolute top-5 left-5">
                    <span className="badge-gold">{quickViewItem.badge}</span>
                  </div>
              }
              </div>

              {/* Details */}
              <div className="p-8 md:p-10 flex flex-col">
                {/* Category + SKU */}
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[11px] font-bold uppercase tracking-[0.18em] text-primary">
                    {quickViewItem.category} · {quickViewItem.subcategory}
                  </span>
                  <span className="text-[11px] font-mono text-muted-light bg-cream-dark px-2 py-1 rounded">
                    {quickViewItem.sku}
                  </span>
                </div>

                {/* Name */}
                <h2 className="font-display text-2xl md:text-3xl font-medium text-foreground leading-tight mb-4">
                  {quickViewItem.name}
                </h2>

                {/* Price */}
                <div className="flex items-baseline gap-3 mb-6">
                  <span className="font-display text-3xl font-medium text-foreground">
                    {formatNGN(quickViewItem.price)}
                  </span>
                  {quickViewItem.originalPrice &&
                <>
                      <span className="text-lg text-muted line-through">
                        {formatNGN(quickViewItem.originalPrice)}
                      </span>
                      <span className="text-sm font-bold text-green-600">
                        {Math.round((quickViewItem.originalPrice - quickViewItem.price) / quickViewItem.originalPrice * 100)}% off
                      </span>
                    </>
                }
                </div>

                {/* Description */}
                <p className="text-muted leading-relaxed mb-6 text-sm">
                  {quickViewItem.description}
                </p>

                {/* Specs */}
                <div className="space-y-3 mb-8 p-5 bg-cream-dark rounded-2xl">
                  {[
                { label: 'Dimensions', value: quickViewItem.dimensions },
                { label: 'Material', value: quickViewItem.material },
                { label: 'Colour', value: quickViewItem.color },
                { label: 'Stock', value: quickViewItem.inStock > 0 ? `${quickViewItem.inStock} units available` : 'Out of stock' }].
                map(({ label, value }) =>
                <div key={label} className="flex justify-between gap-4">
                      <span className="text-[11px] font-bold uppercase tracking-[0.15em] text-muted flex-shrink-0">
                        {label}
                      </span>
                      <span className="text-sm font-medium text-foreground text-right">
                        {value}
                      </span>
                    </div>
                )}
                </div>

                {/* Availability indicator */}
                <div className="flex items-center gap-2 mb-6">
                  <div className={`w-2 h-2 rounded-full ${quickViewItem.available && quickViewItem.inStock > 0 ? 'bg-green-500 animate-pulse' : 'bg-red-400'}`} />
                  <span className="text-sm font-medium text-muted">
                    {quickViewItem.available && quickViewItem.inStock > 0 ?
                  `In stock — ${quickViewItem.inStock} unit${quickViewItem.inStock > 1 ? 's' : ''} available` :
                  'Currently out of stock'}
                  </span>
                </div>

                {/* CTAs */}
                <div className="flex flex-col gap-3 mt-auto">
                  {quickViewItem.available && quickViewItem.inStock > 0 ?
                <>
                      <a
                    href={`https://wa.me/2348000000000?text=Hello, I'm interested in ${quickViewItem.name} (${quickViewItem.sku}) priced at ${formatNGN(quickViewItem.price)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-gold flex items-center justify-center gap-3 py-4 rounded-full font-bold text-[14px] uppercase tracking-[0.12em]">
                    
                        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                        </svg>
                        Enquire on WhatsApp
                      </a>
                      <a
                    href="tel:+2348000000000"
                    className="btn-outline flex items-center justify-center gap-3 py-4 rounded-full font-bold text-[14px] uppercase tracking-[0.12em]">
                    
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                        </svg>
                        Call to Order
                      </a>
                    </> :

                <button
                  className="w-full py-4 rounded-full font-bold text-[14px] uppercase tracking-[0.12em] bg-cream-dark text-muted cursor-not-allowed border border-[var(--color-border)]"
                  disabled>
                  
                      Currently Unavailable
                    </button>
                }
                </div>
              </div>
            </div>
          </div>
        </div>
      }
    </div>);

}
import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ShowroomCatalog from './components/ShowroomCatalog';

export default function ShowroomItemsPage() {
  return (
    <main className="bg-background min-h-screen">
      <Header />
      <ShowroomCatalog />
      <Footer />
    </main>
  );
}
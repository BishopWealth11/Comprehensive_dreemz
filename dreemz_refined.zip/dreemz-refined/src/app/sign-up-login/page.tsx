'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import AppLogo from '@/components/ui/AppLogo';
import AppImage from '@/components/ui/AppImage';

type UserRole = 'admin' | 'manager' | 'accountant' | 'hr' | 'showroom_staff' | 'viewer';

interface RoleConfig {
  label: string;
  description: string;
  color: string;
  icon: React.ReactNode;
}

const roleConfigs: Record<UserRole, RoleConfig> = {
  admin: {
    label: 'Administrator',
    description: 'Full system access',
    color: 'text-red-500 bg-red-50 border-red-200',
    icon: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
      </svg>
    ),
  },
  manager: {
    label: 'Manager',
    description: 'Operations & team oversight',
    color: 'text-blue-600 bg-blue-50 border-blue-200',
    icon: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
      </svg>
    ),
  },
  accountant: {
    label: 'Accountant',
    description: 'Financial records & reports',
    color: 'text-green-600 bg-green-50 border-green-200',
    icon: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
      </svg>
    ),
  },
  hr: {
    label: 'HR',
    description: 'Human resources & staff',
    color: 'text-purple-600 bg-purple-50 border-purple-200',
    icon: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
      </svg>
    ),
  },
  showroom_staff: {
    label: 'Showroom Staff',
    description: 'Inventory & sales floor',
    color: 'text-amber-600 bg-amber-50 border-amber-200',
    icon: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
      </svg>
    ),
  },
  viewer: {
    label: 'Viewer',
    description: 'Read-only access',
    color: 'text-gray-600 bg-gray-50 border-gray-200',
    icon: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
      </svg>
    ),
  },
};

const bgImages = [
  'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&q=80&w=1200',
  'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&q=80&w=1200',
  'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&q=80&w=1200',
  'https://images.unsplash.com/photo-1615529182904-14819c35db37?auto=format&fit=crop&q=80&w=1200',
];

const bgAlts = [
  'Elegant living room interior design by Dreemz',
  'Modern luxury penthouse living space',
  'Premium bedroom interior with upholstered headboard',
  'Sophisticated dining room with statement chandelier',
];

export default function SignUpLoginPage() {
  const [activeTab, setActiveTab] = useState<'login' | 'signup'>('login');
  const [showPassword, setShowPassword] = useState(false);
  const [currentBg, setCurrentBg] = useState(0);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [selectedRole, setSelectedRole] = useState<UserRole>('showroom_staff');
  const [showRoleDropdown, setShowRoleDropdown] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotSent, setForgotSent] = useState(false);
  const [showDemoAccounts, setShowDemoAccounts] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentBg((prev) => (prev + 1) % bgImages.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), 1800);
  };

  const handleForgotPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setForgotSent(true);
  };

  const currentRoleConfig = roleConfigs[selectedRole];

  const demoAccounts: { role: UserRole; email: string; password: string }[] = [
    { role: 'admin', email: 'admin@dreemz.com', password: 'Admin@2025' },
    { role: 'manager', email: 'manager@dreemz.com', password: 'Manager@2025' },
    { role: 'accountant', email: 'accounts@dreemz.com', password: 'Accounts@2025' },
    { role: 'hr', email: 'hr@dreemz.com', password: 'HRDreemz@2025' },
    { role: 'showroom_staff', email: 'showroom@dreemz.com', password: 'Showroom@2025' },
    { role: 'viewer', email: 'viewer@dreemz.com', password: 'Viewer@2025' },
  ];

  const fillDemo = (account: { role: UserRole; email: string; password: string }) => {
    setEmail(account.email);
    setPassword(account.password);
    setSelectedRole(account.role);
    setShowDemoAccounts(false);
  };

  return (
    <div className="min-h-screen flex bg-background">
      {/* Left Panel — Image Gallery */}
      <div className="hidden lg:flex lg:w-[55%] relative overflow-hidden">
        {bgImages.map((src, i) => (
          <div
            key={i}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              i === currentBg ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <AppImage
              src={src}
              alt={bgAlts[i]}
              fill
              className="object-cover"
              priority={i === 0}
              sizes="55vw"
            />
          </div>
        ))}

        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-dark/70 via-dark/40 to-dark/60 z-10" />

        {/* Content on image */}
        <div className="relative z-20 flex flex-col justify-between p-12 w-full">
          {/* Logo */}
          <Link href="/homepage" className="flex items-center gap-3">
            <AppLogo size={36} />
            <span className="font-display font-semibold text-xl text-white tracking-display">
              Dreemz
            </span>
          </Link>

          {/* Bottom quote */}
          <div>
            <div className="mb-8">
              <svg className="w-12 h-12 text-primary/60 mb-4" fill="currentColor" viewBox="0 0 24 24">
                <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
              </svg>
              <p className="font-display text-2xl font-light italic text-white leading-relaxed max-w-sm">
                Every space holds the potential to inspire. We simply help it find its voice.
              </p>
            </div>
            <div className="flex items-center gap-4 border-t border-white/15 pt-6">
              <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                <span className="font-display font-semibold text-primary text-sm">D</span>
              </div>
              <div>
                <div className="font-semibold text-white text-sm">Dreemz Design Team</div>
                <div className="text-white/50 text-xs">Interior & Exterior Concepts</div>
              </div>
            </div>

            {/* Image dots */}
            <div className="flex gap-2 mt-6">
              {bgImages.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentBg(i)}
                  className={`h-1 rounded-full transition-all duration-300 ${
                    i === currentBg ? 'w-8 bg-primary' : 'w-2 bg-white/30'
                  }`}
                  aria-label={`View image ${i + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Right Panel — Form */}
      <div className="flex-1 flex flex-col justify-center px-6 py-12 lg:px-16 xl:px-20 overflow-y-auto">
        {/* Mobile logo */}
        <div className="lg:hidden mb-10">
          <Link href="/homepage" className="flex items-center gap-3">
            <AppLogo size={32} />
            <span className="font-display font-semibold text-lg text-foreground">Dreemz</span>
          </Link>
        </div>

        <div className="max-w-md w-full mx-auto">
          {/* Forgot password flow */}
          {showForgotPassword ? (
            <div>
              <button
                onClick={() => { setShowForgotPassword(false); setForgotSent(false); }}
                className="flex items-center gap-2 text-muted text-sm mb-8 hover:text-foreground transition-colors"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
                Back to login
              </button>

              {forgotSent ? (
                <div className="text-center py-8">
                  <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-6">
                    <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <h2 className="font-display text-2xl font-medium text-foreground mb-3">Check your email</h2>
                  <p className="text-muted text-sm leading-relaxed">
                    We&apos;ve sent password reset instructions to{' '}
                    <span className="font-semibold text-foreground">{forgotEmail}</span>
                  </p>
                </div>
              ) : (
                <>
                  <h2 className="font-display text-3xl font-medium text-foreground mb-2">Reset password</h2>
                  <p className="text-muted text-sm mb-8">Enter your email address and we&apos;ll send reset instructions.</p>
                  <form onSubmit={handleForgotPassword} className="space-y-6">
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-[0.18em] text-muted mb-2">
                        Email Address
                      </label>
                      <input
                        type="email"
                        value={forgotEmail}
                        onChange={(e) => setForgotEmail(e.target.value)}
                        placeholder="your@email.com"
                        required
                        className="input-dreemz"
                      />
                    </div>
                    <button type="submit" className="btn-gold w-full py-4 rounded-full font-bold text-[14px] uppercase tracking-[0.15em]">
                      Send Reset Link
                    </button>
                  </form>
                </>
              )}
            </div>
          ) : (
            <>
              {/* Tabs */}
              <div className="flex bg-cream-dark rounded-full p-1 mb-10">
                {(['login', 'signup'] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`flex-1 py-2.5 rounded-full text-[13px] font-bold uppercase tracking-[0.12em] transition-all duration-300 ${
                      activeTab === tab
                        ? 'bg-foreground text-white shadow-sm'
                        : 'text-muted hover:text-foreground'
                    }`}
                  >
                    {tab === 'login' ? 'Sign In' : 'Request Access'}
                  </button>
                ))}
              </div>

              {/* Heading */}
              <div className="mb-8">
                <h1 className="font-display text-[clamp(1.8rem,3vw,2.8rem)] font-medium text-foreground leading-tight mb-2">
                  {activeTab === 'login' ? 'Welcome back' : 'Join Dreemz'}
                </h1>
                <p className="text-muted text-sm">
                  {activeTab === 'login' ?'Sign in to your staff portal to manage operations.' :'Request access to the Dreemz management platform.'}
                </p>
              </div>

              {/* Demo Accounts Panel (login only) */}
              {activeTab === 'login' && (
                <div className="mb-6">
                  <button
                    type="button"
                    onClick={() => setShowDemoAccounts(!showDemoAccounts)}
                    className="w-full flex items-center justify-between px-4 py-3 rounded-2xl border border-dashed border-primary/40 bg-primary/5 hover:bg-primary/10 transition-colors group"
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="text-lg">🔑</span>
                      <div className="text-left">
                        <div className="text-[12px] font-bold uppercase tracking-[0.15em] text-primary">Demo Login Credentials</div>
                        <div className="text-[11px] text-muted">Click to view all test accounts</div>
                      </div>
                    </div>
                    <svg
                      className={`w-4 h-4 text-primary transition-transform duration-300 ${showDemoAccounts ? 'rotate-180' : ''}`}
                      fill="none" stroke="currentColor" viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>

                  {showDemoAccounts && (
                    <div className="mt-2 bg-white border border-[var(--color-border)] rounded-2xl overflow-hidden shadow-lg">
                      <div className="px-4 py-3 bg-cream-dark border-b border-[var(--color-border)]">
                        <p className="text-[11px] text-muted font-semibold uppercase tracking-[0.12em]">
                          Click any account to auto-fill credentials
                        </p>
                      </div>
                      {demoAccounts.map((account) => {
                        const config = roleConfigs[account.role];
                        return (
                          <button
                            key={account.role}
                            type="button"
                            onClick={() => fillDemo(account)}
                            className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-cream-dark transition-colors text-left border-b border-[var(--color-border)] last:border-0 group"
                          >
                            <div className={`w-9 h-9 rounded-full border flex items-center justify-center flex-shrink-0 ${config.color}`}>
                              {config.icon}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="text-sm font-semibold text-foreground">{config.label}</div>
                              <div className="text-xs text-muted font-mono truncate">{account.email}</div>
                            </div>
                            <div className="text-right flex-shrink-0">
                              <div className="text-xs font-mono text-muted/70 bg-cream-dark px-2 py-1 rounded-lg group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                                {account.password}
                              </div>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}

              {/* Role indicator (login) */}
              {activeTab === 'login' && (
                <div className="mb-6 p-3 rounded-2xl border bg-cream-dark border-[var(--color-border)] flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-full border flex items-center justify-center flex-shrink-0 ${currentRoleConfig.color}`}>
                    {currentRoleConfig.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-bold text-foreground">{currentRoleConfig.label}</div>
                    <div className="text-xs text-muted truncate">{currentRoleConfig.description}</div>
                  </div>
                  <button
                    onClick={() => setShowRoleDropdown(!showRoleDropdown)}
                    className="text-xs text-primary font-semibold hover:underline"
                  >
                    Change
                  </button>
                </div>
              )}

              {/* Role dropdown */}
              {showRoleDropdown && activeTab === 'login' && (
                <div className="mb-6 bg-white border border-[var(--color-border)] rounded-2xl overflow-hidden shadow-lg">
                  {(Object.entries(roleConfigs) as [UserRole, RoleConfig][]).map(([role, config]) => (
                    <button
                      key={role}
                      onClick={() => { setSelectedRole(role); setShowRoleDropdown(false); }}
                      className={`w-full flex items-center gap-3 px-4 py-3 hover:bg-cream-dark transition-colors text-left border-b border-[var(--color-border)] last:border-0 ${
                        selectedRole === role ? 'bg-cream-dark' : ''
                      }`}
                    >
                      <div className={`w-8 h-8 rounded-full border flex items-center justify-center flex-shrink-0 ${config.color}`}>
                        {config.icon}
                      </div>
                      <div>
                        <div className="text-sm font-semibold text-foreground">{config.label}</div>
                        <div className="text-xs text-muted">{config.description}</div>
                      </div>
                      {selectedRole === role && (
                        <svg className="w-4 h-4 text-primary ml-auto flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      )}
                    </button>
                  ))}
                </div>
              )}

              {/* Form */}
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Name (signup only) */}
                {activeTab === 'signup' && (
                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-[0.18em] text-muted mb-2">
                      Full Name
                    </label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Chidi Okafor"
                      required
                      className="input-dreemz"
                    />
                  </div>
                )}

                {/* Email */}
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-[0.18em] text-muted mb-2">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your@dreemz.com"
                    required
                    className="input-dreemz"
                  />
                </div>

                {/* Password */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="block text-[11px] font-bold uppercase tracking-[0.18em] text-muted">
                      Password
                    </label>
                    {activeTab === 'login' && (
                      <button
                        type="button"
                        onClick={() => setShowForgotPassword(true)}
                        className="text-[11px] font-semibold text-primary hover:text-primary-dark transition-colors"
                      >
                        Forgot password?
                      </button>
                    )}
                  </div>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••••"
                      required
                      className="input-dreemz pr-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-0 bottom-3 text-muted hover:text-foreground transition-colors"
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                    >
                      {showPassword ? (
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />
                        </svg>
                      ) : (
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                        </svg>
                      )}
                    </button>
                  </div>
                </div>

                {/* Role select (signup) */}
                {activeTab === 'signup' && (
                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-[0.18em] text-muted mb-2">
                      Your Role
                    </label>
                    <select
                      value={selectedRole}
                      onChange={(e) => setSelectedRole(e.target.value as UserRole)}
                      className="input-dreemz appearance-none cursor-pointer"
                    >
                      {(Object.entries(roleConfigs) as [UserRole, RoleConfig][]).map(([role, config]) => (
                        <option key={role} value={role}>{config.label}</option>
                      ))}
                    </select>
                  </div>
                )}

                {/* Remember me (login) */}
                {activeTab === 'login' && (
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="remember" className="w-4 h-4 accent-primary rounded" />
                    <label htmlFor="remember" className="text-sm text-muted cursor-pointer">
                      Keep me signed in
                    </label>
                  </div>
                )}

                {/* Submit */}
                <button
                  type="submit"
                  disabled={isLoading}
                  className="btn-gold w-full py-4 rounded-full font-bold text-[14px] uppercase tracking-[0.15em] flex items-center justify-center gap-3 disabled:opacity-70"
                >
                  {isLoading ? (
                    <>
                      <svg className="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                      </svg>
                      {activeTab === 'login' ? 'Signing in...' : 'Submitting...'}
                    </>
                  ) : (
                    activeTab === 'login' ? 'Sign In to Portal' : 'Request Access'
                  )}
                </button>
              </form>

              {/* Footer note */}
              <div className="mt-8 pt-6 border-t border-[var(--color-border)]">
                {activeTab === 'login' ? (
                  <p className="text-sm text-muted text-center">
                    Need access?{' '}
                    <button
                      onClick={() => setActiveTab('signup')}
                      className="text-primary font-semibold hover:text-primary-dark transition-colors"
                    >
                      Request an account
                    </button>
                  </p>
                ) : (
                  <p className="text-sm text-muted text-center">
                    Already have access?{' '}
                    <button
                      onClick={() => setActiveTab('login')}
                      className="text-primary font-semibold hover:text-primary-dark transition-colors"
                    >
                      Sign in here
                    </button>
                  </p>
                )}
                <p className="text-xs text-muted/60 text-center mt-4 leading-relaxed">
                  This portal is for Dreemz staff only.{' '}
                  <Link href="/homepage" className="text-primary/70 hover:text-primary transition-colors">
                    Visit public site
                  </Link>
                </p>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
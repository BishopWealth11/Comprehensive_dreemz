'use client';

import React, { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import AppLogo from '@/components/ui/AppLogo';

const navLinks = [
  { label: 'Showroom', href: '/showroom-items', type: 'link' as const },
  { label: 'Portfolio', href: '/portfolio', type: 'link' as const },
  { label: 'Inventory', href: '/inventory', type: 'link' as const },
  { label: 'Accounting', href: '/accounting', type: 'link' as const },
  { label: 'Services', href: '/homepage#services', type: 'anchor' as const },
  { label: 'About', href: '/homepage#about', type: 'anchor' as const },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleScroll = useCallback(() => setScrolled(window.scrollY > 60), []);

  useEffect(() => {
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [handleScroll]);

  const closeMobile = useCallback(() => setMobileOpen(false), []);

  return (
    <header
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${
        scrolled ? 'nav-scrolled py-3' : 'py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-10 flex items-center justify-between">
        {/* Logo */}
        <Link href="/homepage" className="flex items-center gap-3 group">
          <AppLogo
            size={36}
            onClick={() => {}}
            className="transition-transform duration-300 group-hover:scale-105"
          />
          <span className="font-display font-semibold text-xl tracking-display text-foreground hidden sm:block">
            Dreemz
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8 text-[12px] font-semibold uppercase tracking-[0.18em] text-muted">
          {navLinks.map(({ label, href, type }) =>
            type === 'link' ? (
              <Link key={label} href={href} className="hover:text-foreground transition-colors duration-200">
                {label}
              </Link>
            ) : (
              <a key={label} href={href} className="hover:text-foreground transition-colors duration-200">
                {label}
              </a>
            )
          )}
        </nav>

        {/* Right CTAs */}
        <div className="flex items-center gap-3">
          <Link
            href="/sign-up-login"
            className="hidden sm:inline-flex items-center gap-2 text-[12px] font-semibold uppercase tracking-[0.18em] text-muted hover:text-foreground transition-colors duration-200"
          >
            Sign In
          </Link>
          <Link
            href="/homepage#contact"
            className="btn-gold inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-[12px] font-bold uppercase tracking-[0.12em]"
          >
            Book Consultation
          </Link>

          {/* Mobile toggle */}
          <button
            onClick={() => setMobileOpen((v) => !v)}
            className="md:hidden p-2 text-foreground"
            aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
            aria-expanded={mobileOpen}
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {mobileOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={`md:hidden transition-all duration-300 overflow-hidden ${
          mobileOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
        }`}
        style={{ background: 'rgba(250, 248, 243, 0.97)', backdropFilter: 'blur(20px)' }}
      >
        <nav className="px-6 py-6 flex flex-col gap-5 border-t border-[var(--color-border)]">
          {navLinks.map(({ label, href, type }) =>
            type === 'link' ? (
              <Link
                key={label}
                href={href}
                onClick={closeMobile}
                className="text-[13px] font-semibold uppercase tracking-[0.18em] text-muted hover:text-foreground transition-colors"
              >
                {label}
              </Link>
            ) : (
              <a
                key={label}
                href={href}
                onClick={closeMobile}
                className="text-[13px] font-semibold uppercase tracking-[0.18em] text-muted hover:text-foreground transition-colors"
              >
                {label}
              </a>
            )
          )}
          <Link
            href="/sign-up-login"
            onClick={closeMobile}
            className="text-[13px] font-semibold uppercase tracking-[0.18em] text-muted hover:text-foreground transition-colors"
          >
            Staff Login
          </Link>
        </nav>
      </div>
    </header>
  );
}

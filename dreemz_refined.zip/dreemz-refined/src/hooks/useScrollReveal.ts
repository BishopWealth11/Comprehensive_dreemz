import { useEffect, RefObject } from 'react';

/**
 * Shared hook — adds "revealed" to .scroll-reveal / .stagger-children
 * elements when they enter the viewport.
 */
export function useScrollReveal(
  sectionRef: RefObject<HTMLElement | null>,
  threshold = 0.1
) {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('revealed');
          }
        });
      },
      { threshold }
    );

    const elements = sectionRef.current?.querySelectorAll(
      '.scroll-reveal, .stagger-children'
    );
    elements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, [sectionRef, threshold]);
}

/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#C9A84C',
          dark: '#A8872E',
          light: '#E8D08A',
        },
        accent: {
          DEFAULT: '#8B4513',
          light: '#B5621A',
        },
        background: '#FAF8F3',
        foreground: '#1A1209',
        dark: {
          DEFAULT: '#0F0D08',
          card: '#1C1812',
        },
        muted: {
          DEFAULT: '#6B5E4A',
          light: '#A89880',
        },
        cream: {
          DEFAULT: '#FAF8F3',
          dark: '#F0EBE0',
          darker: '#E8E0D0',
        },
      },
      fontFamily: {
        sans: ['DM Sans', 'sans-serif'],
        display: ['Fraunces', 'serif'],
      },
      letterSpacing: {
        tightest: '-0.04em',
        display: '-0.02em',
      },
      borderRadius: {
        '4xl': '2rem',
        '5xl': '2.5rem',
      },
      animation: {
        'gradient': 'gradientShift 8s ease infinite',
        'float': 'float 4s ease-in-out infinite',
        'pulse-glow': 'pulseGlow 2.5s ease-in-out infinite',
        'shimmer': 'shimmer 2s infinite',
        'slow-spin': 'slowSpin 20s linear infinite',
      },
    },
  },
  plugins: [],
};